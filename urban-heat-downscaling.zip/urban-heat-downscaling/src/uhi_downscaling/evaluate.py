"""Evaluate trained downscaling models on the held-out test split.

This module produces the full evaluation artefacts of the pipeline:

1. Loads the trained residual CNN checkpoint written by
   :mod:`uhi_downscaling.train` (``runs/<experiment>/best.pt``) and fits (or
   loads) the gradient-boosting baseline.
2. Computes, on the **test split only**, the overall RMSE / MAE / mean bias
   of three methods against the fine-grid truth:

   * ``bilinear`` - the coarse field bilinearly upscaled to the fine grid
     (the physical no-ML baseline),
   * ``gbm`` - pixelwise gradient boosting trained on the training split,
   * ``cnn`` - the residual CNN.

   plus two breakdowns: **per hour of day** (RMSE of each hour bucket) and
   **per region** (fine-grid cell centres grouped by their geohash-4 prefix,
   i.e. roughly 20 km x 30 km cells around Cairo).
3. Runs a **spatial-holdout experiment**: a fresh CNN and a fresh GBM are
   trained only on west-half pixels and evaluated on east-half pixels of the
   test split, quantifying how each model degrades outside its training
   support.
4. Writes ``results/summary.json``, ``results/report.md`` and PNG figures
   (via :mod:`uhi_downscaling.viz`, Agg backend, dpi=150).

Usage:

    python -m uhi_downscaling.evaluate --config configs/exp_default.yaml
"""

from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch

from uhi_downscaling.config import (
    data_zarr_path,
    experiment_name,
    load_config,
    set_seed,
    split_bounds,
    stats_path,
)
from uhi_downscaling.data.dataset import (
    DownscalingDataset,
    compute_norm_stats,
    load_norm_stats,
    load_synthetic,
    save_norm_stats,
)
from uhi_downscaling.data.geohash import decode as geohash_decode
from uhi_downscaling.data.geohash import encode as geohash_encode
from uhi_downscaling.metrics import mae, mean_bias, rmse
from uhi_downscaling.models.cnn import count_parameters
from uhi_downscaling.models.gbm import (
    build_feature_rows,
    fit_baseline,
    load_model,
    predict_maps,
    save_model,
)
from uhi_downscaling.train import build_model, predict_residual_physical, run_training
from uhi_downscaling.viz import (
    plot_hourly_rmse,
    plot_map_comparison,
    plot_region_rmse,
    plot_scatter,
)

# Geohash precision for the per-region breakdown. At Cairo's latitude a
# precision-4 cell is roughly 20 km (N-S) x 30 km (E-W), so the 48 x 48 km
# domain is covered by a handful of cells.
GEOHASH_PRECISION = 4
# Cap on feature rows used to fit the (pixelwise) GBM baselines.
GBM_MAX_ROWS = 300_000
# Training epochs for the spatial-holdout CNN (kept small on purpose).
HOLDOUT_EPOCHS = 6

METHODS = ("bilinear", "gbm", "cnn")


# ---------------------------------------------------------------------------
# metric helpers
# ---------------------------------------------------------------------------


def _metric_dict(pred: np.ndarray, truth: np.ndarray) -> dict[str, float]:
    """RMSE / MAE / mean bias of ``pred`` against ``truth`` (any shape)."""
    return {
        "rmse_c": rmse(pred, truth),
        "mae_c": mae(pred, truth),
        "mean_bias_c": mean_bias(pred, truth),
    }


def _hour_breakdown(
    preds: dict[str, np.ndarray], truth: np.ndarray, hours: np.ndarray
) -> list[dict[str, Any]]:
    """Per-hour-of-day RMSE rows consumed by :func:`viz.plot_hourly_rmse`."""
    rows: list[dict[str, Any]] = []
    for hour in range(24):
        sel = hours == hour
        if not bool(sel.any()):
            continue
        rows.append(
            {
                "hour": int(hour),
                "n_timesteps": int(sel.sum()),
                "rmse_c": {
                    name: rmse(pred[sel], truth[sel]) for name, pred in preds.items()
                },
            }
        )
    return rows


def _region_masks(lat: np.ndarray, lon: np.ndarray, precision: int) -> dict[str, np.ndarray]:
    """Group fine-grid cells into geohash-prefix regions.

    Args:
        lat: ``(H,)`` latitudes of the fine rows.
        lon: ``(W,)`` longitudes of the fine columns.
        precision: Geohash precision (characters).

    Returns:
        Mapping ``geohash -> (H, W) boolean pixel mask``, sorted by key.
    """
    n_rows, n_cols = lat.size, lon.size
    groups: dict[str, list[tuple[int, int]]] = {}
    for i in range(n_rows):
        for j in range(n_cols):
            key = geohash_encode(float(lat[i]), float(lon[j]), precision)
            groups.setdefault(key, []).append((i, j))
    masks: dict[str, np.ndarray] = {}
    for key, cells in groups.items():
        mask = np.zeros((n_rows, n_cols), dtype=bool)
        idx = np.asarray(cells)
        mask[idx[:, 0], idx[:, 1]] = True
        masks[key] = mask
    return dict(sorted(masks.items()))


def _region_breakdown(
    preds: dict[str, np.ndarray],
    truth: np.ndarray,
    lat: np.ndarray,
    lon: np.ndarray,
    precision: int,
) -> list[dict[str, Any]]:
    """Per-region RMSE rows consumed by :func:`viz.plot_region_rmse`."""
    rows: list[dict[str, Any]] = []
    for key, mask in _region_masks(lat, lon, precision).items():
        center_lat, center_lon = geohash_decode(key)
        rows.append(
            {
                "geohash": key,
                "center_lat": float(center_lat),
                "center_lon": float(center_lon),
                "n_pixels": int(mask.sum()),
                "rmse_c": {
                    name: rmse(pred[:, mask], truth[:, mask])
                    for name, pred in preds.items()
                },
            }
        )
    return rows


# ---------------------------------------------------------------------------
# model loading / fitting
# ---------------------------------------------------------------------------


def _load_cnn(checkpoint_path: str | Path, device: torch.device) -> tuple[torch.nn.Module, dict[str, Any]]:
    """Load a CNN checkpoint saved by :func:`uhi_downscaling.train.run_training`."""
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    model = build_model(checkpoint["model_cfg"])
    model.load_state_dict(checkpoint["state_dict"])
    model.to(device).eval()
    return model, checkpoint


def _ensure_gbm(
    train_ds: DownscalingDataset,
    seed: int,
    path: str | Path,
    pixel_mask: np.ndarray | None = None,
    label: str = "GBM",
) -> tuple[Any, dict[str, Any]]:
    """Load a pickled GBM from ``path`` or fit one on ``train_ds`` rows.

    Rows are restricted to ``pixel_mask`` (when given) and subsampled to at
    most :data:`GBM_MAX_ROWS` with a seeded generator for determinism.
    """
    path = Path(path)
    if path.is_file():
        gbm = load_model(path)
        print(f"loaded {label} from {path}")
        return gbm, {"path": str(path), "loaded": True}
    rng = np.random.default_rng(seed)
    features, targets, _ = build_feature_rows(
        train_ds.upscaled,
        train_ds.static_stack,
        train_ds.residual,
        train_ds.hours,
        pixel_mask=pixel_mask,
        rng=rng,
        max_rows=GBM_MAX_ROWS,
    )
    started = time.perf_counter()
    gbm = fit_baseline(features, targets, seed=seed)
    wall = time.perf_counter() - started
    save_model(gbm, path)
    meta = {
        "path": str(path),
        "loaded": False,
        "n_fit_rows": int(features.shape[0]),
        "n_iterations": int(getattr(gbm, "n_iter_", 0)),
        "fit_wall_time_s": round(wall, 1),
    }
    print(f"fitted {label} on {features.shape[0]} rows in {wall:.1f}s -> {path}")
    return gbm, meta


# ---------------------------------------------------------------------------
# spatial holdout experiment
# ---------------------------------------------------------------------------


def _run_holdout(
    cfg: dict[str, Any],
    ds: Any,
    stats: dict[str, Any],
    bounds: dict[str, tuple[int, int]],
    factor: int,
    train_ds: DownscalingDataset,
    test_ds: DownscalingDataset,
    seed: int,
    device: torch.device,
    run_dir: Path,
) -> dict[str, Any]:
    """Train on the west half of the domain, evaluate on the east half.

    The CNN (masked loss on west pixels) and the GBM (rows from west pixels)
    are both trained from scratch; predictions are scored on east-half pixels
    of the test split only. The bilinear baseline needs no training and is
    scored on the same pixels for reference.
    """
    n = int(cfg["grid"]["n_fine"])
    half = n // 2
    west = np.zeros((n, n), dtype=bool)
    west[:, :half] = True
    east = ~west

    holdout_cfg: dict[str, Any] = {
        **{k: v for k, v in cfg["model"].items()},
        "epochs": HOLDOUT_EPOCHS,
        "batch_size": int(cfg["model"]["batch_size"]) * 2,
    }
    ckpt_dir = Path(run_dir) / "holdout_west"
    best_path = ckpt_dir / "best.pt"

    cnn_meta: dict[str, Any] = {"epochs": HOLDOUT_EPOCHS}
    if best_path.is_file():
        cnn, checkpoint = _load_cnn(best_path, device)
        cnn_meta.update(
            {
                "loaded_from": str(best_path),
                "best_epoch": checkpoint.get("epoch"),
                "val_rmse_c_west": checkpoint.get("val_rmse_c"),
            }
        )
        print(f"loaded holdout CNN from {best_path}")
    else:
        set_seed(seed)
        torch.manual_seed(seed)
        model = build_model(holdout_cfg).to(device)
        train_west = DownscalingDataset(
            ds, bounds["train"], stats, factor, pixel_mask=west, name="train-west"
        )
        val_west = DownscalingDataset(
            ds, bounds["val"], stats, factor, pixel_mask=west, name="val-west"
        )
        result = run_training(
            model,
            train_west,
            val_west,
            holdout_cfg,
            seed,
            device,
            stats=stats,
            pixel_mask=west,
            checkpoint_dir=ckpt_dir,
            log_prefix="[holdout] ",
            meta={"experiment": f"{experiment_name(cfg)}_holdout_west"},
        )
        cnn_meta.update(
            {
                "best_epoch": result["best_epoch"],
                "val_rmse_c_west": result["best_val_rmse_c"],
                "wall_time_s": round(result["wall_time_s"], 1),
            }
        )
        cnn, _ = _load_cnn(best_path, device)

    gbm_west, gbm_meta = _ensure_gbm(
        train_ds,
        seed,
        ckpt_dir / "gbm_west.pkl",
        pixel_mask=west,
        label="holdout GBM (west pixels)",
    )

    cnn_residual = predict_residual_physical(cnn, test_ds, device)
    gbm_residual = predict_maps(
        gbm_west, test_ds.upscaled, test_ds.static_stack, test_ds.hours, pixel_mask=east
    )
    preds = {
        "bilinear": test_ds.upscaled,
        "gbm": test_ds.upscaled + gbm_residual,
        "cnn": test_ds.upscaled + cnn_residual,
    }
    truth = test_ds.fine_truth
    overall = {
        name: _metric_dict(pred[:, east], truth[:, east]) for name, pred in preds.items()
    }
    return {
        "description": (
            "CNN and GBM trained only on west-half pixels "
            f"(columns 0-{half - 1}); metrics computed on east-half pixels "
            f"(columns {half}-{n - 1}) of the test split. Bilinear baseline "
            "scored on the same pixels."
        ),
        "overall_east_half": overall,
        "cnn": cnn_meta,
        "gbm": gbm_meta,
        "_preds": preds,  # internal, stripped before serialisation
    }


# ---------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------


def _fmt(value: float, digits: int = 3) -> str:
    return f"{value:.{digits}f}"


def _metric_table(overall: dict[str, dict[str, float]], indent: str = "") -> str:
    lines = [
        "| Method | RMSE (C) | MAE (C) | Mean bias (C) |",
        "|---|---|---|---|",
    ]
    base = overall["bilinear"]["rmse_c"]
    for name in METHODS:
        row = overall[name]
        skill = 100.0 * (base - row["rmse_c"]) / base if base > 0 else 0.0
        lines.append(
            f"| {name} | {_fmt(row['rmse_c'])} | {_fmt(row['mae_c'])} "
            f"| {_fmt(row['mean_bias_c'], 3)} ({skill:+.1f}% RMSE vs bilinear) |"
        )
    return "\n".join(indent + line for line in lines)


def _write_report(
    summary: dict[str, Any], cfg: dict[str, Any], report_path: Path
) -> None:
    """Render the markdown evaluation report next to ``summary.json``."""
    exp = summary["experiment"]
    test = summary["test_split"]
    lines: list[str] = [
        f"# Evaluation report - {exp}",
        "",
        f"Generated {summary['generated_utc']} (UTC) on device `{summary['device']}` "
        f"with config `{Path(cfg['_config_path']).name}`.",
        "",
        "## Test split",
        "",
        f"{test['n_timesteps']} hourly timesteps (days {test['days'][0]}-{test['days'][1]}, "
        f"1-based day range of a {cfg['time']['n_days']}-day dataset). The models never "
        "saw these timesteps; normalisation statistics come from the training split only.",
        "",
        "## Overall metrics (test split)",
        "",
        _metric_table(summary["overall_test"]),
        "",
        "## RMSE by hour of day",
        "",
        "| Hour | n | Bilinear | GBM | CNN |",
        "|---|---|---|---|---|",
    ]
    for row in summary["by_hour"]:
        r = row["rmse_c"]
        lines.append(
            f"| {row['hour']:02d}:00 | {row['n_timesteps']} "
            f"| {_fmt(r['bilinear'])} | {_fmt(r['gbm'])} | {_fmt(r['cnn'])} |"
        )
    lines += [
        "",
        "## RMSE by region (geohash precision 4, ~20-30 km cells)",
        "",
        "| Region | Centre (lat, lon) | Pixels | Bilinear | GBM | CNN |",
        "|---|---|---|---|---|---|",
    ]
    for row in summary["by_region_geohash4"]:
        r = row["rmse_c"]
        lines.append(
            f"| `{row['geohash']}` | {row['center_lat']:.3f}, {row['center_lon']:.3f} "
            f"| {row['n_pixels']} | {_fmt(r['bilinear'])} | {_fmt(r['gbm'])} "
            f"| {_fmt(r['cnn'])} |"
        )

    holdout = summary["spatial_holdout"]
    lines += [
        "",
        "## Spatial holdout: train west half, evaluate east half",
        "",
        holdout["description"],
        "",
        _metric_table(holdout["overall_east_half"]),
        "",
        "Both learned models are evaluated strictly outside their training support, "
        "so these errors quantify spatial generalisation rather than interpolation.",
        "",
        "## Figures",
        "",
        "![Test snapshot map comparison](figures/test_map_comparison.png)",
        "",
        "![Prediction vs truth scatter](figures/test_scatter.png)",
        "",
        "![RMSE by hour of day](figures/rmse_by_hour.png)",
        "",
        "![RMSE by region](figures/rmse_by_region.png)",
        "",
        "![Spatial holdout map comparison](figures/holdout_map_comparison.png)",
        "",
    ]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: run the full evaluation and write all artefacts."""
    parser = argparse.ArgumentParser(
        description="Evaluate bilinear / GBM / CNN downscaling on the test split."
    )
    parser.add_argument(
        "--config", default="configs/exp_default.yaml", help="Path to the experiment YAML config."
    )
    args = parser.parse_args(argv)

    started = time.perf_counter()
    cfg = load_config(args.config)
    seed = int(cfg["experiment"]["seed"])
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    factor = int(cfg["grid"]["coarsening_factor"])
    bounds = split_bounds(cfg)
    exp = experiment_name(cfg)
    run_dir = Path(cfg["paths"]["runs_dir"]) / exp
    results_dir = Path(cfg["paths"]["results_dir"])
    figures_dir = results_dir / "figures"

    checkpoint_path = run_dir / "best.pt"
    if not checkpoint_path.is_file():
        raise FileNotFoundError(
            f"no CNN checkpoint at {checkpoint_path}; run "
            "`python -m uhi_downscaling.train --config <config>` first"
        )

    ds = load_synthetic(data_zarr_path(cfg))
    stats_file = stats_path(cfg)
    if stats_file.is_file():
        stats = load_norm_stats(stats_file)
        print(f"loaded normalisation stats from {stats_file}")
    else:
        stats = compute_norm_stats(ds, bounds["train"], factor)
        save_norm_stats(stats, stats_file)
        print(f"computed and saved normalisation stats to {stats_file}")

    train_ds = DownscalingDataset(ds, bounds["train"], stats, factor, name="train")
    test_ds = DownscalingDataset(ds, bounds["test"], stats, factor, name="test")

    # --- CNN ---------------------------------------------------------------
    cnn, checkpoint = _load_cnn(checkpoint_path, device)
    cnn_residual = predict_residual_physical(cnn, test_ds, device)

    # --- GBM ---------------------------------------------------------------
    gbm, gbm_meta = _ensure_gbm(train_ds, seed, run_dir / "gbm.pkl", label="GBM")
    gbm_residual = predict_maps(gbm, test_ds.upscaled, test_ds.static_stack, test_ds.hours)

    # --- predictions & metrics --------------------------------------------
    truth = test_ds.fine_truth
    preds: dict[str, np.ndarray] = {
        "bilinear": test_ds.upscaled,
        "gbm": test_ds.upscaled + gbm_residual,
        "cnn": test_ds.upscaled + cnn_residual,
    }
    overall = {name: _metric_dict(preds[name], truth) for name in METHODS}
    hour_rows = _hour_breakdown(preds, truth, np.asarray(test_ds.hours))
    region_rows = _region_breakdown(
        preds, truth, np.asarray(ds["lat"].values), np.asarray(ds["lon"].values),
        GEOHASH_PRECISION,
    )

    print("\noverall test metrics (C):")
    base_rmse = overall["bilinear"]["rmse_c"]
    for name in METHODS:
        row = overall[name]
        skill = 100.0 * (base_rmse - row["rmse_c"]) / base_rmse
        print(
            f"  {name:<9} rmse {row['rmse_c']:.3f}  mae {row['mae_c']:.3f}  "
            f"bias {row['mean_bias_c']:+.3f}  ({skill:+.1f}% vs bilinear)"
        )

    # --- spatial holdout ---------------------------------------------------
    print("\nspatial holdout (train west / evaluate east):")
    holdout = _run_holdout(
        cfg, ds, stats, bounds, factor, train_ds, test_ds, seed, device, run_dir
    )
    holdout_base = holdout["overall_east_half"]["bilinear"]["rmse_c"]
    for name in METHODS:
        row = holdout["overall_east_half"][name]
        skill = 100.0 * (holdout_base - row["rmse_c"]) / holdout_base
        print(f"  {name:<9} rmse {row['rmse_c']:.3f}  ({skill:+.1f}% vs bilinear)")

    # --- figures -----------------------------------------------------------
    figures_dir.mkdir(parents=True, exist_ok=True)
    residual_std = test_ds.residual.std(axis=(1, 2))
    t_star = int(np.argmax(residual_std))
    stamp = str(test_ds.times[t_star])[:16]
    hour_star = int(test_ds.hours[t_star])
    print(f"\nwriting figures to {figures_dir} (snapshot {stamp}) ...")
    plot_map_comparison(
        preds["bilinear"][t_star],
        preds["cnn"][t_star],
        truth[t_star],
        f"Test snapshot {stamp} (hour {hour_star:02d}:00 local solar time)",
        figures_dir / "test_map_comparison.png",
    )
    plot_scatter(preds, truth, figures_dir / "test_scatter.png")
    plot_hourly_rmse(hour_rows, figures_dir / "rmse_by_hour.png")
    plot_region_rmse(region_rows, figures_dir / "rmse_by_region.png")
    plot_map_comparison(
        holdout["_preds"]["bilinear"][t_star],
        holdout["_preds"]["cnn"][t_star],
        truth[t_star],
        f"Spatial holdout (train west / evaluate east) - snapshot {stamp}",
        figures_dir / "holdout_map_comparison.png",
    )

    # --- summary.json ------------------------------------------------------
    summary: dict[str, Any] = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "experiment": exp,
        "config_path": cfg["_config_path"],
        "device": str(device),
        "test_split": {
            "days": [int(d) for d in cfg["split"]["test_days"]],
            "bounds": [int(bounds["test"][0]), int(bounds["test"][1])],
            "n_timesteps": int(len(test_ds)),
        },
        "models": {
            "cnn": {
                "checkpoint": str(checkpoint_path),
                "n_parameters": int(checkpoint.get("n_parameters", count_parameters(cnn))),
                "best_epoch": checkpoint.get("epoch"),
                "val_rmse_c": checkpoint.get("val_rmse_c"),
            },
            "gbm": {"n_features": 10, **gbm_meta},
        },
        "overall_test": overall,
        "by_hour": hour_rows,
        "by_region_geohash4": region_rows,
        "geohash_precision": GEOHASH_PRECISION,
        "spatial_holdout": {k: v for k, v in holdout.items() if not k.startswith("_")},
        "wall_time_s": round(time.perf_counter() - started, 1),
    }
    results_dir.mkdir(parents=True, exist_ok=True)
    summary_path = results_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    report_path = results_dir / "report.md"
    _write_report(summary, cfg, report_path)

    print(f"\nwrote {summary_path}")
    print(f"wrote {report_path}")
    print(f"evaluation finished in {summary['wall_time_s']}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
