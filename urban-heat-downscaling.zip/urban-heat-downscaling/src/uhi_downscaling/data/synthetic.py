"""Generate physically-motivated synthetic urban temperature fields.

The generator produces hourly 2 m temperature fields over a 48 x 48 km
domain (1 km grid, centred on Cairo at 30.05 N, 31.23 E) by superposing
physically motivated components:

* **Diurnal cycle** of the rural background temperature, peaking at 14:00
  local solar time with a day-to-day modulated amplitude (~7.5 C half range).
* **Urban heat island** proportional to a smoothed urban/industrial influence
  map, strongest at night (~4.5 C in the dense core around 04:00, ~1.2 C
  during the day).
* **Park cooling** (evapotranspiration and shading), strongest in the
  afternoon (~0.6-2.4 C scaled by the park fraction).
* **Water cooling** from a lake and a meandering river band (~1.4-2.2 C).
* **Industrial waste heat**, slightly stronger at night (~1.0-1.8 C).
* **Road heating** of asphalt corridors during the day (up to ~1.4 C).
* **Terrain lapse rate** of -6.5 C/km applied to a gentle synthetic
  elevation map (~40-280 m).
* **Smooth advective noise**: a gaussian-smoothed random field (std ~0.3 C,
  ~2 km correlation length) drawn independently at every hour, plus a
  smoother per-day spatial weather anomaly (~0.5 C, ~6 km correlation).

Static predictors (urban/industrial/park/water/road fraction maps,
elevation, mean building height) are generated once and shared by all
timesteps; they play the role of the land-surface covariates a real
downscaling pipeline would consume from land-cover and building datasets.

The coarse field is produced by *exact* 8 x 8 block-mean aggregation of the
fine field, so the coarse-to-fine task is well posed: there is a unique
ground truth and the bilinear upsampling of the coarse field is a well
defined baseline.

Run as a module:

    python -m uhi_downscaling.data.synthetic --config configs/exp_default.yaml

The dataset is written to ``data/synthetic.zarr`` (xarray + zarr) with real
latitude/longitude coordinates, an ``hour`` coordinate and full metadata.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import xarray as xr

# Physical constants used by the generator.
LAPSE_RATE_C_PER_KM = 6.5           # environmental lapse rate
KMS_PER_DEG_LAT = 110.574           # length of one degree of latitude (km)
KMS_PER_DEG_LON_EQUATOR = 111.320   # length of one degree of longitude at the equator

BASE_TEMP_C = 29.5     # July mean rural background temperature (Cairo)
DIURNAL_AMP_C = 7.5    # half range of the rural diurnal cycle
PEAK_HOUR = 14         # hour of maximum temperature (local solar time)
UHI_PEAK_HOUR = 4      # hour of strongest urban heat island
UHI_MIN_C = 1.2        # daytime UHI strength in the dense core
UHI_MAX_C = 3.3        # additional night-time UHI strength
NOISE_STD_C = 0.30     # std of the hourly advective noise field
ANOMALY_STD_C = 0.50   # std of the per-day spatial weather anomaly

# Names of the static predictor variables written to the dataset.
STATIC_VARIABLES: tuple[str, ...] = (
    "urban_frac",
    "industrial_frac",
    "park_frac",
    "water_frac",
    "road_frac",
    "elevation",
    "building_height",
)


def _gaussian_kernel1d(sigma: float) -> np.ndarray:
    """1-D gaussian kernel with a radius of 3 sigma (normalised to sum 1)."""
    if sigma <= 0:
        return np.array([1.0])
    radius = max(1, int(3.0 * sigma + 0.5))
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-0.5 * (x / sigma) ** 2)
    return kernel / kernel.sum()


def gaussian_smooth2d(field: np.ndarray, sigma: float) -> np.ndarray:
    """Separable gaussian filter with edge-replication padding.

    Implemented with plain numpy (no scipy dependency) so the generator is
    fully self-contained.
    """
    kernel = _gaussian_kernel1d(sigma)
    radius = len(kernel) // 2
    padded = np.pad(field, ((0, 0), (radius, radius)), mode="edge")
    out = np.apply_along_axis(lambda row: np.convolve(row, kernel, mode="valid"), 1, padded)
    padded = np.pad(out, ((radius, radius), (0, 0)), mode="edge")
    out = np.apply_along_axis(lambda col: np.convolve(col, kernel, mode="valid"), 0, padded)
    return out


def _smooth1d(values: np.ndarray, sigma: float) -> np.ndarray:
    """1-D gaussian smoothing with reflect padding (keeps the length)."""
    kernel = _gaussian_kernel1d(sigma)
    radius = len(kernel) // 2
    padded = np.pad(np.asarray(values, dtype=np.float64), (radius, radius), mode="reflect")
    return np.convolve(padded, kernel, mode="valid")


def _normalize_std(field: np.ndarray) -> np.ndarray:
    """Return the field re-centred and rescaled to unit standard deviation."""
    std = float(field.std())
    if std <= 1e-12:
        return np.zeros_like(field)
    return (field - field.mean()) / std


def block_mean_aggregate(fine: np.ndarray, factor: int) -> np.ndarray:
    """Aggregate a ``(..., H, W)`` fine field by exact ``factor x factor`` block means.

    This is the deterministic operator that defines the coarse field, so the
    downscaling task is well posed. The last two dimensions must be divisible
    by ``factor``.
    """
    if fine.shape[-2] % factor != 0 or fine.shape[-1] % factor != 0:
        raise ValueError(f"spatial shape {fine.shape[-2:]} not divisible by factor {factor}")
    n_cy = fine.shape[-2] // factor
    n_cx = fine.shape[-1] // factor
    lead = fine.shape[:-2]
    blocks = fine.reshape(lead + (n_cy, factor, n_cx, factor))
    return blocks.mean(axis=(-3, -1), dtype=np.float64).astype(np.float32)


def build_coordinates(grid: dict[str, Any]) -> dict[str, np.ndarray]:
    """Build real latitude/longitude coordinates for the fine and coarse grids.

    Fine cell centres sit at offsets ``(i + 0.5 - n/2) * spacing`` km from the
    domain centre along each axis; coarse block centres are the block means of
    those positions (offsets ``(8j + 4 - n/2)`` km for ``factor=8``).
    """
    n = int(grid["n_fine"])
    spacing = float(grid["fine_spacing_km"])
    factor = int(grid["coarsening_factor"])
    if n % factor != 0:
        raise ValueError(f"n_fine ({n}) must be divisible by coarsening_factor ({factor})")
    center_lat = float(grid["center_lat"])
    center_lon = float(grid["center_lon"])

    deg_per_km_lat = 1.0 / KMS_PER_DEG_LAT
    kms_per_deg_lon = KMS_PER_DEG_LON_EQUATOR * np.cos(np.deg2rad(center_lat))

    fine_offset_km = (np.arange(n, dtype=np.float64) + 0.5 - n / 2.0) * spacing
    n_c = n // factor
    coarse_offset_km = (np.arange(n_c, dtype=np.float64) + 0.5 - n_c / 2.0) * spacing * factor

    return {
        "lat": center_lat + fine_offset_km * deg_per_km_lat,          # increasing north
        "lon": center_lon + fine_offset_km / kms_per_deg_lon,         # increasing east
        "lat_c": center_lat + coarse_offset_km * deg_per_km_lat,
        "lon_c": center_lon + coarse_offset_km / kms_per_deg_lon,
        "fine_offset_km": fine_offset_km,
    }


def generate_static_fields(grid: dict[str, Any], rng: np.random.Generator) -> dict[str, np.ndarray]:
    """Generate the static land-surface predictor maps (all arrays are (n, n)).

    Land-cover fractions are allocated sequentially (water, parks, industry,
    roads, urban) so that the five fractions always sum to at most one; the
    remainder is bare/desert surface, which is not used as a predictor.
    """
    n = int(grid["n_fine"])
    offsets = build_coordinates(grid)["fine_offset_km"]
    x_grid, y_grid = np.meshgrid(offsets, offsets)  # x varies along dim 1 (lon), y along dim 0 (lat)

    def bump(cx: float, cy: float, sigma: float, amp: float) -> np.ndarray:
        return amp * np.exp(-0.5 * ((x_grid - cx) ** 2 + (y_grid - cy) ** 2) / sigma**2)

    # Gentle elevation map (~40-280 m): two hills plus a broad plateau, with
    # a small amount of smooth roughness for realism.
    elevation = 40.0 + bump(14.0, 12.0, 13.0, 180.0) + bump(-14.0, -12.0, 11.0, 110.0) + bump(0.0, 16.0, 16.0, 60.0)
    elevation = elevation + 8.0 * gaussian_smooth2d(rng.standard_normal((n, n)), 3.0)
    elevation = np.clip(elevation, 5.0, None)

    # Raw potentials for each land-cover class.
    urban_raw = bump(-4.0, 2.0, 8.0, 0.90) + bump(12.0, 8.0, 6.0, 0.45) + bump(-14.0, 6.0, 5.0, 0.30)
    industrial_raw = bump(16.0, -14.0, 5.0, 0.65) + bump(-16.0, 14.0, 4.0, 0.40)
    park_raw = (
        bump(-8.0, -14.0, 3.0, 0.70)
        + bump(-14.0, 12.0, 3.5, 0.60)
        + bump(8.0, 18.0, 3.0, 0.65)
        + bump(20.0, 0.0, 2.5, 0.55)
        + bump(2.0, -4.0, 2.5, 0.50)
    )
    lake = bump(-18.0, -8.0, 3.0, 1.00)
    river_center_x = 3.5 + 3.0 * np.sin(2.0 * np.pi * (y_grid + n / 2.0) / 44.0)
    river = 0.95 * np.exp(-0.5 * ((x_grid - river_center_x) / 0.8) ** 2)
    water_raw = np.maximum(lake, river)
    ring = 0.30 * np.exp(-0.5 * ((np.sqrt(x_grid**2 + y_grid**2) - 16.0) / 0.7) ** 2)
    highway_y = 0.32 * np.exp(-0.5 * ((y_grid + 8.0) / 0.6) ** 2)
    highway_x = 0.30 * np.exp(-0.5 * ((x_grid - 10.0) / 0.6) ** 2)
    road_raw = np.maximum(np.maximum(ring, highway_y), highway_x)

    # Sequential allocation guarantees fractions in [0, 1] summing to <= 1.
    water = np.clip(water_raw, 0.0, 0.95)
    room = 1.0 - water
    park = np.clip(park_raw, 0.0, np.minimum(room, 0.70))
    room = room - park
    industrial = np.clip(industrial_raw, 0.0, np.minimum(room, 0.65))
    room = room - industrial
    road = np.clip(road_raw, 0.0, np.minimum(room, 0.25))
    room = room - road
    urban = np.clip(urban_raw, 0.0, np.minimum(room, 0.95))
    bare = np.clip(room - urban, 0.0, None)

    roughness = gaussian_smooth2d(rng.standard_normal((n, n)), 1.5)
    building_height = np.clip(3.5 + 15.0 * urban + 9.0 * industrial + 2.0 * roughness, 2.0, 45.0)

    # Neighbourhood-averaged urban influence: waste heat and heat storage in
    # a pixel also warm its surroundings (advected), so the temperature at a
    # pixel depends on land cover in a ~5 km neighbourhood. Pixelwise models
    # cannot reconstruct this from their own features; convolutional models
    # can.
    urban_influence = gaussian_smooth2d(urban + 0.6 * industrial + 0.15 * road, 2.5)

    return {
        "urban_frac": urban.astype(np.float32),
        "industrial_frac": industrial.astype(np.float32),
        "park_frac": park.astype(np.float32),
        "water_frac": water.astype(np.float32),
        "road_frac": road.astype(np.float32),
        "bare_frac": bare.astype(np.float32),
        "elevation": elevation.astype(np.float32),
        "building_height": building_height.astype(np.float32),
        "urban_influence": urban_influence.astype(np.float32),
    }


def _hourly_strength(hour: float, peak_hour: float) -> float:
    """Smooth periodic factor in [0, 1] peaking at ``peak_hour``."""
    return 0.5 + 0.5 * np.cos(2.0 * np.pi * (hour - peak_hour) / 24.0)


def generate_timeseries(
    static: dict[str, np.ndarray],
    grid: dict[str, Any],
    time_cfg: dict[str, Any],
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate fine and coarse temperature fields for all hourly timesteps.

    Returns:
        Tuple ``(fine, coarse)`` with shapes ``(T, n, n)`` and
        ``(T, n/factor, n/factor)``, both float32 and in degrees Celsius.
    """
    n = int(grid["n_fine"])
    factor = int(grid["coarsening_factor"])
    n_days = int(time_cfg["n_days"])
    if n_days < 1:
        raise ValueError("n_days must be >= 1")
    total = n_days * 24

    urban = static["urban_frac"]
    industrial = static["industrial_frac"]
    park = static["park_frac"]
    water = static["water_frac"]
    road = static["road_frac"]
    influence = static["urban_influence"]
    lapse_term = LAPSE_RATE_C_PER_KM * static["elevation"] / 1000.0

    # Smooth day-to-day variability of the mean and the diurnal amplitude.
    mean_anom = _smooth1d(rng.standard_normal(n_days), 2.0) * 1.2
    amp_anom = _smooth1d(rng.standard_normal(n_days), 2.0) * 0.8

    # Per-day spatial weather anomaly (same field for all hours of a day).
    spatial_anom = np.empty((n_days, n, n), dtype=np.float32)
    for day in range(n_days):
        field = gaussian_smooth2d(rng.standard_normal((n, n)), 6.0)
        spatial_anom[day] = (_normalize_std(field) * ANOMALY_STD_C).astype(np.float32)

    fine = np.empty((total, n, n), dtype=np.float32)
    for t in range(total):
        day, hour = divmod(t, 24)
        noise = gaussian_smooth2d(rng.standard_normal((n, n)), 2.2)
        noise = (_normalize_std(noise) * NOISE_STD_C).astype(np.float32)

        base = (
            BASE_TEMP_C
            + mean_anom[day]
            + (DIURNAL_AMP_C + amp_anom[day]) * np.cos(2.0 * np.pi * (hour - PEAK_HOUR) / 24.0)
        )
        uhi_strength = UHI_MIN_C + UHI_MAX_C * _hourly_strength(hour, UHI_PEAK_HOUR) ** 2
        park_cool = 0.6 + 1.8 * _hourly_strength(hour, PEAK_HOUR)
        water_cool = 1.4 + 0.8 * _hourly_strength(hour, PEAK_HOUR)
        industrial_heat = 1.0 + 0.8 * _hourly_strength(hour, UHI_PEAK_HOUR)
        road_heat = 0.4 + 1.0 * _hourly_strength(hour, PEAK_HOUR)

        fine[t] = (
            base
            + uhi_strength * influence
            - park_cool * park
            - water_cool * water
            + industrial_heat * industrial
            + road_heat * road
            - lapse_term
            + spatial_anom[day]
            + noise
        )

    coarse = block_mean_aggregate(fine, factor)
    return fine, coarse


def generate_dataset(cfg: dict[str, Any]) -> xr.Dataset:
    """Generate the full synthetic dataset as an :class:`xarray.Dataset`.

    Uses ``cfg["grid"]``, ``cfg["time"]`` and ``cfg["experiment"]["seed"]``.
    Everything is deterministic for a fixed seed.
    """
    grid = cfg["grid"]
    time_cfg = cfg["time"]
    seed = int(cfg.get("experiment", {}).get("seed", 42))
    rng = np.random.default_rng(seed)

    coords = build_coordinates(grid)
    static = generate_static_fields(grid, rng)
    fine, coarse = generate_timeseries(static, grid, time_cfg, rng)

    n_days = int(time_cfg["n_days"])
    total = n_days * 24
    times = np.datetime64(f"{str(time_cfg['start_date'])}T00:00:00") + np.arange(
        total, dtype="timedelta64[h]"
    )
    hours = np.tile(np.arange(24, dtype=np.int16), n_days)
    day_index = np.repeat(np.arange(n_days, dtype=np.int16), 24)

    data_vars: dict[str, tuple[tuple[str, str, str], np.ndarray, dict[str, str]]] = {
        "t2m_fine": (
            ("time", "lat", "lon"),
            fine,
            {"units": "degC", "long_name": "2 m temperature on the fine (1 km) grid"},
        ),
        "t2m_coarse": (
            ("time", "lat_c", "lon_c"),
            coarse,
            {"units": "degC", "long_name": "2 m temperature on the coarse block-mean grid"},
        ),
    }
    units = {
        "urban_frac": "1",
        "industrial_frac": "1",
        "park_frac": "1",
        "water_frac": "1",
        "road_frac": "1",
        "elevation": "m",
        "building_height": "m",
    }
    for name in STATIC_VARIABLES:
        data_vars[name] = (("lat", "lon"), static[name], {"units": units[name]})

    factor = int(grid["coarsening_factor"])
    ds = xr.Dataset(
        data_vars=data_vars,
        coords={
            "time": times,
            "lat": ("lat", coords["lat"], {"units": "degrees_north", "long_name": "latitude"}),
            "lon": ("lon", coords["lon"], {"units": "degrees_east", "long_name": "longitude"}),
            "lat_c": ("lat_c", coords["lat_c"], {"units": "degrees_north", "long_name": "latitude"}),
            "lon_c": ("lon_c", coords["lon_c"], {"units": "degrees_east", "long_name": "longitude"}),
            "hour": ("time", hours, {"long_name": "hour of day (local solar time)"}),
            "day_index": ("time", day_index, {"long_name": "0-based day index"}),
        },
        attrs={
            "title": "Synthetic urban heat island downscaling dataset",
            "institution": "generated by uhi_downscaling.data.synthetic",
            "source": "physically-motivated synthetic generator (no real observations)",
            "seed": seed,
            "n_fine": int(grid["n_fine"]),
            "fine_spacing_km": float(grid["fine_spacing_km"]),
            "coarsening_factor": factor,
            "center_lat": float(grid["center_lat"]),
            "center_lon": float(grid["center_lon"]),
            "start_date": str(time_cfg["start_date"]),
            "n_days": n_days,
            "lapse_rate_c_per_km": LAPSE_RATE_C_PER_KM,
            "note": "Coarse field is the exact block-mean of the fine field over "
            f"{factor}x{factor} cells; timestamps are local solar time over the domain.",
        },
    )
    return ds


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: generate the dataset and write it to a zarr store."""
    parser = argparse.ArgumentParser(
        description="Generate the synthetic urban temperature dataset (xarray + zarr)."
    )
    parser.add_argument(
        "--config", default="configs/exp_default.yaml", help="Path to the experiment YAML config."
    )
    parser.add_argument(
        "--out", default=None, help="Output zarr path (default: <data_dir>/synthetic.zarr)."
    )
    args = parser.parse_args(argv)

    from uhi_downscaling.config import data_zarr_path, load_config

    cfg = load_config(args.config)
    out = Path(args.out) if args.out else data_zarr_path(cfg)
    out.parent.mkdir(parents=True, exist_ok=True)

    print(f"Generating synthetic dataset (seed={cfg['experiment']['seed']}) ...")
    ds = generate_dataset(cfg)
    ds.to_zarr(out, mode="w")

    fine = ds["t2m_fine"].values
    print(f"written: {out}")
    print(f"  t2m_fine   shape={fine.shape}  mean={fine.mean():.2f} C  "
          f"min={fine.min():.2f} C  max={fine.max():.2f} C")
    print(f"  t2m_coarse shape={ds['t2m_coarse'].shape}")
    print(f"  urban_frac mean={float(ds['urban_frac'].mean()):.3f}  "
          f"max={float(ds['urban_frac'].max()):.3f}")
    print(f"  time span: {str(ds['time'].values[0])[:16]} .. {str(ds['time'].values[-1])[:16]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
