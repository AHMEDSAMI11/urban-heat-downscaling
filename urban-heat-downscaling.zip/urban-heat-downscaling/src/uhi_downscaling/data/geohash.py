"""Self-contained pure-python geohash encoder/decoder (no third-party deps).

A geohash interleaves longitude and latitude bits (longitude first) and packs
every 5 bits into one base-32 character. Longer strings identify smaller
cells; a shared prefix identifies geographic proximity, which this package
uses to define regions for the per-region error breakdown in
:mod:`uhi_downscaling.evaluate`.

Cell sizes (approximate, at the equator):

===========  ===========  ===========
precision    lat          lon
===========  ===========  ===========
1            2500 km      2500 km
2            625 km       1250 km
3            156 km       156 km
4            19.5 km      39.1 km
5            4.89 km      4.89 km
6            1.22 km      0.61 km
===========  ===========  ===========
"""

from __future__ import annotations

from collections.abc import Iterable

BASE32 = "0123456789bcdefghjkmnpqrstuvwxyz"
_BASE32_INDEX = {char: index for index, char in enumerate(BASE32)}


def encode(lat: float, lon: float, precision: int = 12) -> str:
    """Encode a latitude/longitude pair as a geohash string.

    Args:
        lat: Latitude in degrees, ``-90 <= lat <= 90``.
        lon: Longitude in degrees, ``-180 <= lon <= 180``.
        precision: Number of base-32 characters (5 bits each) to produce.

    Returns:
        The geohash string of exactly ``precision`` characters.

    Raises:
        ValueError: If coordinates are out of range or ``precision < 1``.
    """
    if precision < 1:
        raise ValueError(f"precision must be >= 1, got {precision}")
    if not -90.0 <= lat <= 90.0:
        raise ValueError(f"latitude out of range [-90, 90]: {lat!r}")
    if not -180.0 <= lon <= 180.0:
        raise ValueError(f"longitude out of range [-180, 180]: {lon!r}")

    lat_lo, lat_hi = -90.0, 90.0
    lon_lo, lon_hi = -180.0, 180.0
    chars: list[str] = []
    bit_count = 0
    buffer = 0
    even = True  # geohash interleaves bits starting with longitude
    while len(chars) < precision:
        if even:
            mid = (lon_lo + lon_hi) / 2.0
            if lon >= mid:
                buffer = (buffer << 1) | 1
                lon_lo = mid
            else:
                buffer = buffer << 1
                lon_hi = mid
        else:
            mid = (lat_lo + lat_hi) / 2.0
            if lat >= mid:
                buffer = (buffer << 1) | 1
                lat_lo = mid
            else:
                buffer = buffer << 1
                lat_hi = mid
        even = not even
        bit_count += 1
        if bit_count == 5:
            chars.append(BASE32[buffer])
            bit_count = 0
            buffer = 0
    return "".join(chars)


def decode_bounds(geohash: str) -> tuple[float, float, float, float]:
    """Return the bounding box of a geohash cell.

    Args:
        geohash: The geohash string (case-insensitive).

    Returns:
        Tuple ``(lat_lo, lat_hi, lon_lo, lon_hi)`` in degrees.

    Raises:
        ValueError: If the string contains characters outside the base-32
            alphabet used by geohash.
    """
    lat_lo, lat_hi = -90.0, 90.0
    lon_lo, lon_hi = -180.0, 180.0
    even = True
    for char in geohash.lower():
        try:
            value = _BASE32_INDEX[char]
        except KeyError as exc:
            raise ValueError(f"invalid geohash character: {char!r}") from exc
        for mask in (16, 8, 4, 2, 1):
            bit = value & mask
            if even:
                mid = (lon_lo + lon_hi) / 2.0
                if bit:
                    lon_lo = mid
                else:
                    lon_hi = mid
            else:
                mid = (lat_lo + lat_hi) / 2.0
                if bit:
                    lat_lo = mid
                else:
                    lat_hi = mid
            even = not even
    return lat_lo, lat_hi, lon_lo, lon_hi


def decode(geohash: str) -> tuple[float, float]:
    """Decode a geohash to the ``(lat, lon)`` centre of its cell."""
    lat_lo, lat_hi, lon_lo, lon_hi = decode_bounds(geohash)
    return ((lat_lo + lat_hi) / 2.0, (lon_lo + lon_hi) / 2.0)


def group_by_prefix(
    points: Iterable[tuple[float, float]], precision: int
) -> dict[str, list[tuple[float, float]]]:
    """Group ``(lat, lon)`` points by their geohash cell at a given precision.

    Args:
        points: Iterable of ``(lat, lon)`` tuples in degrees.
        precision: Geohash precision used for grouping.

    Returns:
        Mapping ``geohash -> list of (lat, lon)``. The lists preserve input
        order and the grouping is deterministic.
    """
    groups: dict[str, list[tuple[float, float]]] = {}
    for lat, lon in points:
        key = encode(float(lat), float(lon), precision)
        groups.setdefault(key, []).append((float(lat), float(lon)))
    return groups
