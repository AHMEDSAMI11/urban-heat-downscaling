"""Torch datasets pairing coarse inputs with fine residual targets.

The super-resolution task is framed as *residual learning*: the model input
contains the coarse 2 m temperature field bilinearly upscaled to the fine
grid (the physical baseline) plus seven static land-surface predictors, and
the target is the *residual* ``t2m_fine - bilinear_upsample(t2m_coarse)``.
Predicting only the residual lets the network focus on sub-grid structure
(urban heat island, parks, water bodies, terrain) instead of re-learning the
smooth synoptic signal already captured by the coarse field.

Inputs and targets are z-score normalised; statistics are computed on the
training split only and stored as JSON so that evaluation can invert the
normalisation exactly.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import torch
import xarray as xr
from numpy.typing import ArrayLike
from torch.nn import functional as F
from torch.utils.data import Dataset

STATIC_PREDICTORS: tuple[str, ...] = (
    "urban_frac",
    "industrial_frac",
    "park_frac",
    "water_frac",
    "road_frac",
    "elevation",
    "building_height",
)
INPUT_CHANNEL_NAMES: tuple[str, ...] = (
    "bilinear_t2m",
    *STATIC_PREDICTORS,
    "hour_sin",
    "hour_cos",
)


def bilinear_upsample(
    coarse: np.ndarray, factor: int, out_hw: tuple[int, int] | None = None
) -> np.ndarray:
    """Bilinearly upsample a ``(..., H_c, W_c)`` block-mean field to the fine grid.

    Uses ``align_corners=False``, which evaluates the interpolation at fine
    cell centres. Because coarse block centres coincide with fine-grid
    positions, the result is exactly the piecewise-bilinear reconstruction of
    the coarse field - the natural physical baseline for the downscaling task.

    Args:
        coarse: Array whose last two dimensions are the coarse grid.
        factor: Integer upsampling factor used when ``out_hw`` is not given.
        out_hw: Explicit output spatial size ``(H, W)``.

    Returns:
        Float32 array with the same leading dimensions and fine-grid spatial
        dimensions.
    """
    if out_hw is None:
        out_hw = (coarse.shape[-2] * factor, coarse.shape[-1] * factor)
    arr = np.ascontiguousarray(coarse, dtype=np.float32)
    lead_shape = arr.shape[:-2]
    tensor = torch.from_numpy(arr.reshape((-1,) + arr.shape[-2:])).unsqueeze(1)
    up = F.interpolate(tensor, size=tuple(out_hw), mode="bilinear", align_corners=False)
    return up[:, 0].numpy().reshape(lead_shape + tuple(out_hw))


def load_synthetic(path: str | Path) -> xr.Dataset:
    """Open a generated dataset (zarr store) and load it into memory."""
    ds = xr.open_zarr(str(path))
    return ds.load()


def compute_norm_stats(
    ds: xr.Dataset, train_bounds: tuple[int, int], factor: int
) -> dict[str, Any]:
    """Compute z-score statistics for the model inputs and the residual target.

    Statistics are computed on the training split only, so the validation and
    test splits stay untouched (no leakage).
    """
    start, stop = train_bounds
    ups = bilinear_upsample(ds["t2m_coarse"].values[start:stop], factor)
    residual = ds["t2m_fine"].values[start:stop] - ups

    channels: list[dict[str, Any]] = []

    def add_entry(name: str, arr: np.ndarray) -> None:
        std = float(arr.std())
        channels.append(
            {"name": name, "mean": float(arr.mean()), "std": std if std > 1e-8 else 1.0}
        )

    add_entry("bilinear_t2m", ups)
    for var in STATIC_PREDICTORS:
        add_entry(var, ds[var].values)
    # Hour-of-day encoding channels are already in [-1, 1]; they are listed
    # with identity statistics so the input contract stays uniform.
    channels.append({"name": "hour_sin", "mean": 0.0, "std": 1.0})
    channels.append({"name": "hour_cos", "mean": 0.0, "std": 1.0})

    target_std = float(residual.std())
    target = {
        "name": "fine_residual_t2m",
        "mean": float(residual.mean()),
        "std": target_std if target_std > 1e-8 else 1.0,
    }
    return {
        "input_channels": channels,
        "target": target,
        "n_timesteps": int(stop - start),
        "bounds": [int(start), int(stop)],
    }


def save_norm_stats(stats: Mapping[str, Any], path: str | Path) -> None:
    """Write normalisation statistics to a JSON file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(dict(stats), fh, indent=2)


def load_norm_stats(path: str | Path) -> dict[str, Any]:
    """Read normalisation statistics from a JSON file."""
    with Path(path).open("r", encoding="utf-8") as fh:
        return json.load(fh)


class DownscalingDataset(Dataset):
    """Torch dataset of (normalised inputs, normalised residual target) pairs.

    Each item corresponds to one hourly timestep; the inputs are an
    ``(10, H, W)`` stack (bilinearly-upscaled coarse t2m, seven static
    predictors, and constant hour-of-day sin/cos maps) and the target is the
    ``(H, W)`` fine residual field.

    An optional boolean ``pixel_mask`` restricts which fine pixels belong to
    the sample (used by the spatial holdout experiment); it affects training
    loss and evaluation, not the number of timesteps.
    """

    def __init__(
        self,
        dataset: xr.Dataset,
        bounds: tuple[int, int],
        stats: Mapping[str, Any],
        factor: int = 8,
        pixel_mask: ArrayLike | None = None,
        name: str = "",
    ) -> None:
        """Build the dataset for a contiguous range of hourly timesteps.

        Args:
            dataset: Generated :class:`xarray.Dataset` (see
                :mod:`uhi_downscaling.data.synthetic`).
            bounds: ``[start, stop)`` timestep indices of the split.
            stats: Normalisation statistics (see :func:`compute_norm_stats`).
            factor: Coarsening factor used for the bilinear baseline.
            pixel_mask: Optional ``(H, W)`` boolean mask of usable pixels.
            name: Human-readable label used in logs.
        """
        start, stop = int(bounds[0]), int(bounds[1])
        self.name = name
        self.bounds = (start, stop)

        coarse = dataset["t2m_coarse"].values[start:stop]
        fine = dataset["t2m_fine"].values[start:stop].astype(np.float32)
        self.upscaled = bilinear_upsample(coarse, factor)  # physical baseline (T, H, W)
        self.residual = fine - self.upscaled               # physical target (T, H, W)
        self.fine_truth = fine

        self.static_stack = np.stack(
            [np.asarray(dataset[var].values, dtype=np.float32) for var in STATIC_PREDICTORS]
        )
        self.pixel_mask = (
            None if pixel_mask is None else np.asarray(pixel_mask, dtype=np.bool_)
        )

        channel_stats = stats["input_channels"]
        if tuple(entry["name"] for entry in channel_stats) != INPUT_CHANNEL_NAMES:
            raise ValueError("stats input_channels do not match INPUT_CHANNEL_NAMES")
        self.target_mean = float(stats["target"]["mean"])
        self.target_std = float(stats["target"]["std"])

        self.times = dataset["time"].values[start:stop]
        if "hour" in dataset.coords:
            self.hours = np.asarray(dataset["hour"].values[start:stop], dtype=np.int16)
        else:  # fallback for datasets without an explicit hour coordinate
            stamps = self.times.astype("datetime64[h]")
            day = stamps.astype("datetime64[D]")
            self.hours = ((stamps - day) / np.timedelta64(1, "h")).astype(np.int16)

        n_t, _, _ = self.upscaled.shape
        h, w = self.upscaled.shape[1:]
        inputs = np.empty((n_t, len(INPUT_CHANNEL_NAMES), h, w), dtype=np.float32)
        inputs[:, 0] = (self.upscaled - channel_stats[0]["mean"]) / channel_stats[0]["std"]
        for k, var in enumerate(STATIC_PREDICTORS, start=1):
            inputs[:, k] = (self.static_stack[k - 1] - channel_stats[k]["mean"]) / channel_stats[k]["std"]
        # Constant hour-of-day encoding maps (already unitless, no z-score).
        angle = 2.0 * np.pi * self.hours.astype(np.float64) / 24.0
        inputs[:, len(STATIC_PREDICTORS) + 1] = np.sin(angle)[:, None, None]
        inputs[:, len(STATIC_PREDICTORS) + 2] = np.cos(angle)[:, None, None]
        self.inputs = inputs
        self.targets_norm = ((self.residual - self.target_mean) / self.target_std).astype(
            np.float32
        )

    def __len__(self) -> int:
        return self.inputs.shape[0]

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor]:
        """Return ``(inputs, target_norm)`` tensors for one timestep."""
        x = torch.from_numpy(self.inputs[index])
        y = torch.from_numpy(self.targets_norm[index])
        return x, y

    def denormalize_residual(self, residual_norm: ArrayLike) -> np.ndarray:
        """Map a normalised residual prediction back to degrees Celsius."""
        return np.asarray(residual_norm, dtype=np.float32) * self.target_std + self.target_mean
