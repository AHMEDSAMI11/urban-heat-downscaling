"""Data generation, geohash grouping and torch dataset utilities."""
