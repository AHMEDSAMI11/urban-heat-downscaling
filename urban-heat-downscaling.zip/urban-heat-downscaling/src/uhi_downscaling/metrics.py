"""Regression metrics used across training and evaluation.

All metrics operate on numpy arrays of arbitrary matching shape and are
computed in float64 for numerical stability.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike


def _as_float_arrays(pred: ArrayLike, truth: ArrayLike) -> tuple[np.ndarray, np.ndarray]:
    pred_arr = np.asarray(pred, dtype=np.float64)
    truth_arr = np.asarray(truth, dtype=np.float64)
    if pred_arr.shape != truth_arr.shape:
        raise ValueError(f"shape mismatch: pred {pred_arr.shape} vs truth {truth_arr.shape}")
    if pred_arr.size == 0:
        raise ValueError("cannot compute metrics on empty arrays")
    return pred_arr, truth_arr


def rmse(pred: ArrayLike, truth: ArrayLike) -> float:
    """Root-mean-square error, ``sqrt(mean((pred - truth) ** 2))``."""
    pred_arr, truth_arr = _as_float_arrays(pred, truth)
    return float(np.sqrt(np.mean((pred_arr - truth_arr) ** 2)))


def mae(pred: ArrayLike, truth: ArrayLike) -> float:
    """Mean absolute error, ``mean(|pred - truth|)``."""
    pred_arr, truth_arr = _as_float_arrays(pred, truth)
    return float(np.mean(np.abs(pred_arr - truth_arr)))


def mean_bias(pred: ArrayLike, truth: ArrayLike) -> float:
    """Mean bias, ``mean(pred - truth)``. Positive values mean over-prediction."""
    pred_arr, truth_arr = _as_float_arrays(pred, truth)
    return float(np.mean(pred_arr - truth_arr))
