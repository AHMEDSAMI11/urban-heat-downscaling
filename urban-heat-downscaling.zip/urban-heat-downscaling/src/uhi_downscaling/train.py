"""Train the residual CNN on the synthetic downscaling task.

The training loop uses masked MSE on the z-score-normalised residual target
(the mask restricts the loss to a region of pixels, which the spatial
holdout experiment uses), Adam with cosine-annealed learning rate, and
reports validation RMSE in physical units (degrees Celsius) after every
epoch.

Usage:
    python -m uhi_downscaling.train --config configs/exp_default.yaml

Writes to ``runs/<experiment name>/``:

* ``best.pt``      best-validation checkpoint (state dict + normalisation
                   statistics + model config, everything needed to evaluate),
* ``last.pt``      final-epoch checkpoint,
* ``metrics.json`` per-epoch losses, validation RMSE, wall time, metadata.
"""

from __future__ import annotations

import argparse
import json
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader

from uhi_downscaling.config import (
    data_zarr_path,
    experiment_name,
    load_config,
    set_seed,
    split_bounds,
    stats_path,
)
from uhi_downscaling.data.dataset import (
    DownscalingDataset,
    compute_norm_stats,
    load_norm_stats,
    load_synthetic,
    save_norm_stats,
)
from uhi_downscaling.data.dataset import INPUT_CHANNEL_NAMES
from uhi_downscaling.metrics import rmse
from uhi_downscaling.models.cnn import ResidualCNN, count_parameters


def build_model(model_cfg: Mapping[str, Any]) -> ResidualCNN:
    """Instantiate the residual CNN from the ``model`` section of a config."""
    return ResidualCNN(
        in_channels=len(INPUT_CHANNEL_NAMES),  # bilinear t2m + 7 static + hour sin/cos
        channels=tuple(int(c) for c in model_cfg["channels"]),
        kernel_size=int(model_cfg.get("kernel_size", 3)),
    )


@torch.no_grad()
def predict_residual_physical(
    model: torch.nn.Module,
    dataset: DownscalingDataset,
    device: torch.device,
    batch_size: int = 64,
) -> np.ndarray:
    """Predict the residual for every timestep and de-normalise it to degrees C.

    Returns:
        ``(T, H, W)`` float32 array of predicted residuals.
    """
    model.eval()
    chunks: list[np.ndarray] = []
    for start in range(0, len(dataset), batch_size):
        batch = torch.from_numpy(dataset.inputs[start : start + batch_size]).to(device)
        chunks.append(model(batch)[:, 0].cpu().numpy())
    residual_norm = np.concatenate(chunks, axis=0)
    return residual_norm * dataset.target_std + dataset.target_mean


def run_training(
    model: torch.nn.Module,
    train_ds: DownscalingDataset,
    val_ds: DownscalingDataset,
    model_cfg: Mapping[str, Any],
    seed: int,
    device: torch.device,
    *,
    stats: Mapping[str, Any],
    pixel_mask: np.ndarray | None = None,
    checkpoint_dir: str | Path | None = None,
    log_prefix: str = "",
    meta: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Train ``model`` on the normalised residual target.

    Args:
        model: The (fresh) model to train, already moved to ``device``.
        train_ds: Training dataset.
        val_ds: Validation dataset (used for epoch selection in physical RMSE).
        model_cfg: ``model`` section of the experiment config.
        seed: Torch seed for weight init and dataloader shuffling.
        device: Torch device.
        stats: Normalisation statistics embedded into checkpoints.
        pixel_mask: Optional ``(H, W)`` boolean mask restricting the loss (and
            the validation RMSE) to a region of pixels.
        checkpoint_dir: If given, write ``best.pt`` / ``last.pt`` /
            ``metrics.json`` there.
        log_prefix: Prefix for epoch log lines.
        meta: Extra metadata merged into ``metrics.json``.

    Returns:
        Dict with ``history`` (per-epoch loss/RMSE), ``best_state``,
        ``best_val_rmse_c``, ``best_epoch`` and ``wall_time_s``.
    """
    epochs = int(model_cfg["epochs"])
    batch_size = int(model_cfg["batch_size"])
    torch.manual_seed(seed)
    loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        generator=torch.Generator().manual_seed(seed),
    )

    mask_tensor = None
    if pixel_mask is not None:
        mask_tensor = (
            torch.from_numpy(np.asarray(pixel_mask, dtype=np.float32))
            .to(device)
            .view(1, 1, *pixel_mask.shape)
        )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=float(model_cfg["lr"]),
        weight_decay=float(model_cfg.get("weight_decay", 1e-5)),
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    history: list[dict[str, Any]] = []
    best_val = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    best_epoch = 0
    start = time.perf_counter()

    for epoch in range(1, epochs + 1):
        model.train()
        loss_sum = 0.0
        steps = 0
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            optimizer.zero_grad(set_to_none=True)
            pred = model(xb)
            if mask_tensor is None:
                loss = torch.mean((pred - yb) ** 2)
            else:
                squared_err = (pred - yb) ** 2 * mask_tensor
                # Mean over all masked elements of the batch (mask is a single
                # (H, W) frame broadcast over the batch dimension).
                loss = squared_err.sum() / (mask_tensor.sum() * pred.shape[0])
            loss.backward()
            optimizer.step()
            loss_sum += float(loss.detach())
            steps += 1
        scheduler.step()

        pred_val = predict_residual_physical(model, val_ds, device)
        if pixel_mask is None:
            val_rmse = rmse(pred_val, val_ds.residual)
        else:
            val_rmse = rmse(pred_val[:, pixel_mask], val_ds.residual[:, pixel_mask])
        history.append(
            {
                "epoch": epoch,
                "train_loss": loss_sum / max(steps, 1),
                "val_rmse_c": val_rmse,
                "lr": scheduler.get_last_lr()[0],
            }
        )
        marker = ""
        if val_rmse < best_val:
            best_val = val_rmse
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            marker = "  <- best"
        print(
            f"{log_prefix}epoch {epoch:3d}/{epochs}  "
            f"train_loss {history[-1]['train_loss']:.4f}  "
            f"val_rmse {val_rmse:.3f} C{marker}",
            flush=True,
        )

    wall = time.perf_counter() - start
    result: dict[str, Any] = {
        "history": history,
        "best_state": best_state,
        "best_val_rmse_c": best_val,
        "best_epoch": best_epoch,
        "wall_time_s": wall,
    }

    if checkpoint_dir is not None:
        checkpoint_dir = Path(checkpoint_dir)
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "model_cfg": {
                k: (list(v) if isinstance(v, tuple) else v) for k, v in dict(model_cfg).items()
            },
            "norm_stats": dict(stats),
            "n_parameters": count_parameters(model),
            "torch_version": torch.__version__,
        }
        final_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        torch.save(
            {**payload, "state_dict": final_state, "val_rmse_c": history[-1]["val_rmse_c"], "epoch": epochs},
            checkpoint_dir / "last.pt",
        )
        model.load_state_dict(best_state)
        torch.save(
            {**payload, "state_dict": model.state_dict(), "val_rmse_c": best_val, "epoch": best_epoch},
            checkpoint_dir / "best.pt",
        )
        metrics = {
            **(dict(meta) if meta else {}),
            "history": history,
            "final_val_rmse_c": history[-1]["val_rmse_c"],
            "best_val_rmse_c": best_val,
            "best_epoch": best_epoch,
            "wall_time_s": round(wall, 1),
            "device": str(device),
            "seed": int(seed),
        }
        (checkpoint_dir / "metrics.json").write_text(
            json.dumps(metrics, indent=2), encoding="utf-8"
        )

    return result


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: train the CNN and write checkpoints plus metrics."""
    parser = argparse.ArgumentParser(description="Train the residual CNN downscaling model.")
    parser.add_argument(
        "--config", default="configs/exp_default.yaml", help="Path to the experiment YAML config."
    )
    args = parser.parse_args(argv)

    cfg = load_config(args.config)
    seed = int(cfg["experiment"]["seed"])
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    factor = int(cfg["grid"]["coarsening_factor"])
    bounds = split_bounds(cfg)

    ds = load_synthetic(data_zarr_path(cfg))
    stats_file = stats_path(cfg)
    if stats_file.is_file():
        stats = load_norm_stats(stats_file)
        print(f"loaded normalisation stats from {stats_file}")
    else:
        stats = compute_norm_stats(ds, bounds["train"], factor)
        save_norm_stats(stats, stats_file)
        print(f"computed and saved normalisation stats to {stats_file}")

    train_ds = DownscalingDataset(ds, bounds["train"], stats, factor, name="train")
    val_ds = DownscalingDataset(ds, bounds["val"], stats, factor, name="val")
    model = build_model(cfg["model"]).to(device)
    n_params = count_parameters(model)

    exp = experiment_name(cfg)
    run_dir = Path(cfg["paths"]["runs_dir"]) / exp
    run_dir.mkdir(parents=True, exist_ok=True)
    print(
        f"device={device}  parameters={n_params:,}  train={len(train_ds)}  val={len(val_ds)}  "
        f"run_dir={run_dir}"
    )

    result = run_training(
        model,
        train_ds,
        val_ds,
        cfg["model"],
        seed,
        device,
        stats=stats,
        checkpoint_dir=run_dir,
        meta={
            "experiment": exp,
            "n_train_timesteps": len(train_ds),
            "n_val_timesteps": len(val_ds),
            "n_parameters": n_params,
        },
    )
    print(
        f"done in {result['wall_time_s']:.1f}s  best_val_rmse={result['best_val_rmse_c']:.3f} C "
        f"(epoch {result['best_epoch']})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
