"""Machine-learning downscaling of urban 2 m temperature fields.

This package trains and evaluates models that super-resolve coarse
block-averaged 2 m temperature fields to a 1 km urban grid using static
land-surface predictors (land-cover fractions, elevation, mean building
height). A compact residual CNN is the primary model; a gradient-boosting
baseline and a bilinear-upscaling baseline are used for comparison.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
