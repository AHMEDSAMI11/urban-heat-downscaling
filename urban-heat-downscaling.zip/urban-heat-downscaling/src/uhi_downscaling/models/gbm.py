"""Gradient-boosting baseline operating on flattened pixelwise features.

The GBM baseline deliberately ignores spatial context: every (timestep,
pixel) pair is one independent row with pixelwise predictors only. It
quantifies how much of the residual signal is explainable from *local*
information alone; the CNN should exceed it by exploiting neighbourhood
structure (advection of the urban heat island, smooth industrial plumes,
road corridors, and so on).

Feature vector per row (10 features, see :data:`FEATURE_NAMES`):

* the bilinearly-upscaled coarse t2m at the pixel,
* seven static predictors (five land-cover fractions, elevation, mean
  building height),
* hour-of-day as ``sin``/``cos`` so the tree ensemble can modulate effects
  diurnally (the CNN infers time from the thermal pattern instead).

The model predicts the same residual target as the CNN, so all three methods
(bilinear upscaling, GBM, CNN) are compared on an identical footing.
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
from numpy.typing import ArrayLike
from sklearn.ensemble import HistGradientBoostingRegressor

FEATURE_NAMES: tuple[str, ...] = (
    "bilinear_t2m",
    "urban_frac",
    "industrial_frac",
    "park_frac",
    "water_frac",
    "road_frac",
    "elevation",
    "building_height",
    "hour_sin",
    "hour_cos",
)


def build_feature_rows(
    upscaled: np.ndarray,
    static_stack: np.ndarray,
    residual: np.ndarray,
    hours: ArrayLike,
    pixel_mask: np.ndarray | None = None,
    rng: np.random.Generator | None = None,
    max_rows: int | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Flatten (timestep, pixel) pairs into independent feature rows.

    Args:
        upscaled: ``(T, H, W)`` physical bilinear baseline field.
        static_stack: ``(7, H, W)`` static predictor stack.
        residual: ``(T, H, W)`` physical residual target.
        hours: ``(T,)`` hour-of-day for each timestep.
        pixel_mask: Optional ``(H, W)`` boolean mask; rows are restricted to
            ``True`` pixels.
        rng: numpy Generator used for row subsampling (pass a seeded
            generator for determinism).
        max_rows: Cap on the number of returned rows (uniform subsample over
            all (timestep, pixel) pairs).

    Returns:
        Tuple ``(X, y, index)`` where ``X`` is ``(N, 10)`` float32, ``y`` is
        ``(N,)`` float32 and ``index`` is an ``(N, 3)`` int array of
        ``(timestep, row, col)`` coordinates.
    """
    n_t, n_rows, n_cols = upscaled.shape
    mask = np.ones((n_rows, n_cols), dtype=bool) if pixel_mask is None else np.asarray(pixel_mask, dtype=bool)
    ys, xs = np.nonzero(mask)
    n_pixels = ys.size
    if n_pixels == 0:
        raise ValueError("pixel_mask contains no True pixels")

    ups_flat = np.ascontiguousarray(upscaled, dtype=np.float32).reshape(n_t, n_rows * n_cols)
    res_flat = np.ascontiguousarray(residual, dtype=np.float32).reshape(n_t, n_rows * n_cols)
    pixel_static = np.ascontiguousarray(static_stack, dtype=np.float32)[:, ys, xs].T  # (P, 7)

    total = n_t * n_pixels
    n_rows_out = total if max_rows is None else min(int(max_rows), total)
    if n_rows_out < total:
        if rng is None:
            raise ValueError("rng is required when max_rows causes subsampling")
        chosen = rng.choice(total, size=n_rows_out, replace=False)
    else:
        chosen = np.arange(total)
    chosen.sort()  # groups rows by timestep for friendlier memory access

    t_idx = chosen // n_pixels
    p_idx = chosen % n_pixels
    flat_pixel = ys * n_cols + xs

    features = np.empty((n_rows_out, len(FEATURE_NAMES)), dtype=np.float32)
    features[:, 0] = ups_flat[t_idx, flat_pixel[p_idx]]
    features[:, 1:8] = pixel_static[p_idx]
    angle = 2.0 * np.pi * np.asarray(hours, dtype=np.float64)[t_idx] / 24.0
    features[:, 8] = np.sin(angle)
    features[:, 9] = np.cos(angle)

    targets = res_flat[t_idx, flat_pixel[p_idx]].astype(np.float32)
    index = np.stack([t_idx, ys[p_idx], xs[p_idx]], axis=1)
    return features, targets, index


def fit_baseline(
    X: np.ndarray,
    y: np.ndarray,
    seed: int,
    max_iter: int = 300,
    learning_rate: float = 0.08,
) -> HistGradientBoostingRegressor:
    """Fit a :class:`HistGradientBoostingRegressor` on the residual target.

    Early stopping on an internal 10% validation split keeps the runtime
    bounded; ``random_state`` makes the fit deterministic.
    """
    model = HistGradientBoostingRegressor(
        max_iter=max_iter,
        learning_rate=learning_rate,
        max_bins=128,
        early_stopping=True,
        validation_fraction=0.1,
        n_iter_no_change=25,
        l2_regularization=0.01,
        random_state=seed,
    )
    model.fit(X, y)
    return model


def predict_maps(
    model: HistGradientBoostingRegressor,
    upscaled: np.ndarray,
    static_stack: np.ndarray,
    hours: ArrayLike,
    pixel_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Predict residual maps for every timestep (zero outside ``pixel_mask``).

    Returns:
        ``(T, H, W)`` float32 array of predicted residuals in degrees Celsius.
    """
    n_t, n_rows, n_cols = upscaled.shape
    mask = np.ones((n_rows, n_cols), dtype=bool) if pixel_mask is None else np.asarray(pixel_mask, dtype=bool)
    ys, xs = np.nonzero(mask)
    n_pixels = ys.size
    if n_pixels == 0:
        raise ValueError("pixel_mask contains no True pixels")

    ups_flat = np.ascontiguousarray(upscaled, dtype=np.float32).reshape(n_t, n_rows * n_cols)
    pixel_static = np.ascontiguousarray(static_stack, dtype=np.float32)[:, ys, xs].T
    flat_pixel = ys * n_cols + xs
    t_idx = np.repeat(np.arange(n_t), n_pixels)
    p_idx = np.tile(np.arange(n_pixels), n_t)

    features = np.empty((n_t * n_pixels, len(FEATURE_NAMES)), dtype=np.float32)
    features[:, 0] = ups_flat[t_idx, flat_pixel[p_idx]]
    features[:, 1:8] = pixel_static[p_idx]
    angle = 2.0 * np.pi * np.asarray(hours, dtype=np.float64)[t_idx] / 24.0
    features[:, 8] = np.sin(angle)
    features[:, 9] = np.cos(angle)

    predictions = model.predict(features).reshape(n_t, n_pixels).astype(np.float32)
    out = np.zeros((n_t, n_rows, n_cols), dtype=np.float32)
    out[:, ys, xs] = predictions
    return out


def save_model(model: HistGradientBoostingRegressor, path: str | Path) -> None:
    """Pickle the fitted GBM to ``path`` (creating parent directories)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as fh:
        pickle.dump(model, fh)


def load_model(path: str | Path) -> HistGradientBoostingRegressor:
    """Load a pickled GBM from ``path``."""
    with Path(path).open("rb") as fh:
        return pickle.load(fh)
