"""Compact residual CNN for fine-scale temperature residual prediction.

Why residual learning?
----------------------
The bilinearly-upscaled coarse field already explains the smooth, synoptic
part of the temperature signal (the diurnal cycle and the mesoscale weather
pattern). The physically interesting signal - sub-grid urban heat island,
park and water cooling, industrial waste heat, terrain effects - is a
comparatively small (order 0.5-2 C) perturbation on top of that baseline.
Predicting the *residual* ``t2m_fine - bilinear(t2m_coarse)`` therefore

1. removes most of the variance the network would otherwise have to model,
   so the MSE loss focuses on the sub-grid structure of interest,
2. lets the network start from the baseline instead of re-learning the
   diurnal cycle from scratch, which speeds up convergence on tiny models
   and small datasets, and
3. guarantees the baseline skill as a floor: the final prediction is
   ``bilinear + predicted residual`` and degrades gracefully to the baseline
   if the predicted residual is zero.

The network itself is a small U-Net style encoder-decoder with one skip
connection (~274 k parameters) that maps a 10-channel input (bilinear t2m,
seven static predictors, hour-of-day sin/cos) to a single-channel residual
field. The hour channels let the network modulate static-land-surface
effects diurnally - the same signal the GBM baseline receives as features,
which keeps the two learned models on an identical footing.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import torch
from torch import nn
from torch.nn import functional as F


class ConvBlock(nn.Sequential):
    """(Conv2d -> ReLU) building block with symmetric zero padding."""

    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3, stride: int = 1) -> None:
        super().__init__(
            nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=kernel_size // 2,
                bias=True,
            ),
            nn.ReLU(inplace=True),
        )


class ResidualCNN(nn.Module):
    """Small encoder-decoder CNN predicting the fine-grid residual field.

    Architecture (default ``channels=(48, 64, 96)``, ``kernel_size=3``):

    * stem: ConvBlock(10 -> 48) at the fine 48 x 48 resolution (skip source)
    * down: ConvBlock(48 -> 64, stride 2) to 24 x 24
    * mid: two ConvBlocks at 64 -> 96 -> 96 (bottleneck)
    * up: bilinear upsample back to 48 x 48, ConvBlock(96 -> 64)
    * fuse: concat the stem skip (48 ch), ConvBlock(112 -> 48)
    * head: Conv2d(48 -> 1), the normalised residual field

    The output has the same height/width as the input, so the prediction is
    added element-wise to the bilinear baseline.
    """

    def __init__(
        self,
        in_channels: int = 10,
        channels: Sequence[int] = (48, 64, 96),
        kernel_size: int = 3,
    ) -> None:
        super().__init__()
        if len(channels) != 3:
            raise ValueError("channels must contain three widths: (stem, encoder, bottleneck)")
        c0, c1, c2 = (int(c) for c in channels)
        self.stem = ConvBlock(in_channels, c0, kernel_size)                # fine resolution
        self.down = ConvBlock(c0, c1, kernel_size, stride=2)               # /2 resolution
        self.mid = nn.Sequential(
            ConvBlock(c1, c2, kernel_size),
            ConvBlock(c2, c2, kernel_size),
        )
        self.up = ConvBlock(c2, c1, kernel_size)
        self.fuse = ConvBlock(c1 + c0, c0, kernel_size)
        self.head = nn.Conv2d(c0, 1, kernel_size, padding=kernel_size // 2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Map ``(B, in_channels, H, W)`` to ``(B, 1, H, W)`` normalised residual."""
        skip = self.stem(x)
        hidden = self.down(skip)
        hidden = self.mid(hidden)
        hidden = F.interpolate(hidden, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        hidden = self.up(hidden)
        hidden = self.fuse(torch.cat([hidden, skip], dim=1))
        return self.head(hidden)


def count_parameters(model: nn.Module) -> int:
    """Number of trainable parameters in the model."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
