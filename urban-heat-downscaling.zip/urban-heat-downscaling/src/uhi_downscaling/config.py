"""Configuration loading, path resolution and seeding helpers."""

from __future__ import annotations

import random
from pathlib import Path
from typing import Any

import numpy as np
import yaml

_PATH_KEYS = ("data_dir", "runs_dir", "results_dir")
_PATH_DEFAULTS = {"data_dir": "data", "runs_dir": "runs", "results_dir": "results"}


def load_config(path: str | Path) -> dict[str, Any]:
    """Load a YAML experiment config and resolve relative paths.

    Relative values of ``paths.data_dir`` / ``paths.runs_dir`` /
    ``paths.results_dir`` are resolved against the repository root, defined
    as the parent of the directory containing the config file (configs live
    in ``<root>/configs``). The resolved config path is stored under the
    ``_config_path`` key.

    Args:
        path: Path to the YAML config file.

    Returns:
        The parsed config dictionary with absolute path strings.
    """
    cfg_path = Path(path).resolve()
    if not cfg_path.is_file():
        raise FileNotFoundError(f"config file not found: {cfg_path}")
    with cfg_path.open("r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    if not isinstance(cfg, dict):
        raise ValueError(f"config root must be a mapping: {cfg_path}")
    root = cfg_path.parent.parent
    paths = cfg.setdefault("paths", {})
    for key in _PATH_KEYS:
        value = Path(paths.get(key, _PATH_DEFAULTS[key]))
        paths[key] = str(value if value.is_absolute() else root / value)
    cfg["_config_path"] = str(cfg_path)
    return cfg


def set_seed(seed: int) -> None:
    """Seed the global ``random``, ``numpy`` and (if installed) ``torch`` RNGs."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
    except ImportError:
        return
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def split_bounds(cfg: dict[str, Any]) -> dict[str, tuple[int, int]]:
    """Translate 1-based inclusive day ranges into ``[start, stop)`` indices.

    The dataset is hourly, so day ``d`` covers samples
    ``[(d - 1) * 24, d * 24)``.

    Returns:
        Mapping ``{"train": (start, stop), "val": ..., "test": ...}``.
    """
    hours_per_day = 24
    bounds: dict[str, tuple[int, int]] = {}
    for name in ("train", "val", "test"):
        first_day, last_day = cfg["split"][f"{name}_days"]
        bounds[name] = ((int(first_day) - 1) * hours_per_day, int(last_day) * hours_per_day)
    return bounds


def experiment_name(cfg: dict[str, Any]) -> str:
    """Return the experiment name from the config."""
    return str(cfg["experiment"]["name"])


def data_zarr_path(cfg: dict[str, Any]) -> Path:
    """Path of the generated dataset zarr store."""
    return Path(cfg["paths"]["data_dir"]) / "synthetic.zarr"


def stats_path(cfg: dict[str, Any]) -> Path:
    """Path of the JSON file holding z-score normalisation statistics."""
    return Path(cfg["paths"]["data_dir"]) / "norm_stats.json"
