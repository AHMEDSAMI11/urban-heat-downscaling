"""Matplotlib figures for the evaluation report (Agg backend, dpi=150).

This module imports matplotlib and selects the non-interactive Agg backend
*before* importing pyplot, so it is safe to use on headless machines and in
CI.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402  (backend must be set first)
import numpy as np  # noqa: E402
from pathlib import Path  # noqa: E402

from uhi_downscaling.metrics import rmse  # noqa: E402

# Presentation order/colors for the three compared methods.
METHOD_ORDER: tuple[str, ...] = ("bilinear", "gbm", "cnn")
_LABELS = {
    "bilinear": "Bilinear upscale (baseline)",
    "gbm": "GBM (pixelwise)",
    "cnn": "Residual CNN",
}
_COLORS = {"bilinear": "#7f7f7f", "gbm": "#ff7f0e", "cnn": "#d62728"}


def _save(fig: plt.Figure, out_path: str | Path) -> None:
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_map_comparison(
    bilinear: np.ndarray,
    cnn: np.ndarray,
    truth: np.ndarray,
    title: str,
    out_path: str | Path,
    extent: tuple[float, float, float, float] | None = None,
) -> None:
    """Three-panel map: bilinear baseline vs CNN prediction vs truth.

    Args:
        bilinear: ``(H, W)`` bilinear-upscaled coarse field.
        cnn: ``(H, W)`` CNN prediction (bilinear + predicted residual).
        truth: ``(H, W)`` fine-grid truth field.
        title: Figure suptitle.
        out_path: PNG output path.
        extent: imshow extent in km ``(x0, x1, y0, y1)``; defaults to the
            48 x 48 km domain with 1 km cells.
    """
    if extent is None:
        extent = (-23.5, 23.5, -23.5, 23.5)
    panels = [
        ("Bilinear upscale (baseline)", bilinear),
        ("Residual CNN prediction", cnn),
        ("Fine-grid truth", truth),
    ]
    vmin = float(min(arr.min() for _, arr in panels))
    vmax = float(max(arr.max() for _, arr in panels))
    fig, axes = plt.subplots(1, 3, figsize=(13.0, 4.4), sharey=True)
    for ax, (label, arr) in zip(axes, panels):
        im = ax.imshow(arr, origin="lower", extent=extent, cmap="inferno", vmin=vmin, vmax=vmax)
        ax.set_title(label if label.startswith("Fine") else f"{label}\nRMSE = {rmse(arr, truth):.2f} C",
                     fontsize=10)
        ax.set_xlabel("E-W distance (km)")
    axes[0].set_ylabel("N-S distance (km)")
    fig.colorbar(im, ax=axes, shrink=0.85, pad=0.02, label="2 m temperature (C)")
    fig.suptitle(title)
    _save(fig, out_path)


def plot_scatter(
    preds: dict[str, np.ndarray],
    truth: np.ndarray,
    out_path: str | Path,
    n_sample: int = 15000,
    seed: int = 0,
) -> None:
    """Prediction-vs-truth scatter panels (one per method, shared subsample).

    Args:
        preds: Mapping method name -> ``(T, H, W)`` predicted fine fields.
        truth: ``(T, H, W)`` fine-grid truth.
        out_path: PNG output path.
        n_sample: Number of randomly subsampled points per panel.
        seed: Subsampling seed (deterministic figures).
    """
    rng = np.random.default_rng(seed)
    flat_truth = truth.reshape(-1)
    n = flat_truth.size
    idx = rng.choice(n, size=min(int(n_sample), n), replace=False)

    lo = float(min(flat_truth.min(), min(p.min() for p in preds.values())))
    hi = float(max(flat_truth.max(), max(p.max() for p in preds.values())))

    fig, axes = plt.subplots(
        1, len(preds), figsize=(4.3 * len(preds), 4.4), sharey=True, sharex=True
    )
    axes = np.atleast_1d(axes)
    for ax, name in zip(axes, preds):
        sample_pred = preds[name].reshape(-1)[idx]
        ax.scatter(
            flat_truth[idx], sample_pred, s=3, alpha=0.12,
            color=_COLORS[name], edgecolors="none", rasterized=True,
        )
        ax.plot([lo, hi], [lo, hi], "--", color="0.35", linewidth=1.0)
        ax.set_title(f"{_LABELS[name]}\nRMSE = {rmse(preds[name], truth):.2f} C", fontsize=10)
        ax.set_xlabel("Truth 2 m temperature (C)")
        ax.set_xlim(lo, hi)
        ax.set_ylim(lo, hi)
        ax.set_aspect("equal")
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Predicted 2 m temperature (C)")
    fig.suptitle("Prediction vs truth, test split (subsampled)")
    _save(fig, out_path)


def plot_hourly_rmse(rows: list[dict], out_path: str | Path) -> None:
    """Per-hour-of-day RMSE curves for all three methods.

    Args:
        rows: List of ``{"hour": int, "rmse_c": {method: float}}`` dicts.
        out_path: PNG output path.
    """
    hours = [row["hour"] for row in rows]
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    for name in METHOD_ORDER:
        ax.plot(
            hours,
            [row["rmse_c"][name] for row in rows],
            marker="o",
            markersize=3.5,
            label=_LABELS[name],
            color=_COLORS[name],
        )
    ax.set_xticks(range(0, 24, 2))
    ax.set_xlabel("Hour of day (local solar time)")
    ax.set_ylabel("RMSE (C)")
    ax.grid(alpha=0.3)
    ax.legend()
    ax.set_title("Test RMSE by hour of day")
    _save(fig, out_path)


def plot_region_rmse(rows: list[dict], out_path: str | Path) -> None:
    """Grouped bar chart of per-region RMSE for all three methods.

    Args:
        rows: List of ``{"geohash": str, "n_pixels": int,
            "rmse_c": {method: float}}`` dicts.
        out_path: PNG output path.
    """
    n = len(rows)
    x = np.arange(n)
    width = 0.26
    fig, ax = plt.subplots(figsize=(max(6.0, 1.2 * n + 2.0), 4.4))
    for k, name in enumerate(METHOD_ORDER):
        ax.bar(
            x + (k - 1) * width,
            [row["rmse_c"][name] for row in rows],
            width,
            label=_LABELS[name],
            color=_COLORS[name],
        )
    ax.set_xticks(x)
    ax.set_xticklabels(
        [f"{row['geohash']}\n(n={row['n_pixels']})" for row in rows]
    )
    ax.set_xlabel("Region (geohash prefix, ~20-30 km cells)")
    ax.set_ylabel("RMSE (C)")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    ax.set_title("Test RMSE by region")
    _save(fig, out_path)
