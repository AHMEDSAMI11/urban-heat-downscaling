"""Download real ERA5 2 m temperature for the Cairo region via the CDS API.

This script fetches genuine hourly ERA5 ``2m_temperature`` (``t2m``) fields
from the Copernicus Climate Data Store (CDS) over the same Cairo-centred
domain used by the synthetic generator, and writes a plain netCDF file under
``data/era5/``. It is the entry point for replacing the synthetic data with
real observations (see the README roadmap); converting the downloaded netCDF
into the pipeline's zarr format (``data/synthetic.zarr`` schema) is future
work, so this script only performs the download.

Prerequisites (one-time setup)
------------------------------

1. Register for a free account at https://cds.climate.copernicus.eu.
2. Accept the "ERA5 single levels" dataset licence on your CDS profile page
   (Terms of use section).
3. Copy your personal API key from https://cds.climate.copernicus.eu/how-to-api
   and create the file ``~/.cdsapirc`` containing::

       url: https://cds.climate.copernicus.eu/api
       key: <YOUR-PERSONAL-KEY>

   Alternatively export the ``CDSAPI_URL`` and ``CDSAPI_KEY`` environment
   variables.
4. Install the client library: ``pip install cdsapi`` (not a package
   dependency, since the core pipeline never needs it).

If no key is configured the script prints the instructions above and exits
with status 1 instead of failing with a stack trace.

Usage
-----

    python scripts/download_era5.py --config configs/exp_default.yaml
    python scripts/download_era5.py --start 2023-07-01 --end 2023-07-31

The default date range mirrors the synthetic dataset (``time.start_date``
plus ``time.n_days`` days); ``--start``/``--end`` override it. The default
download grid is 0.25 degrees (the native ERA5 resolution); pass ``--grid
0.1`` for the finer 0.1-degree product (much larger download).
"""

from __future__ import annotations

import argparse
import math
import os
import sys
from collections import OrderedDict
from datetime import date, timedelta
from pathlib import Path
from typing import Any

DEFAULT_CONFIG = "configs/exp_default.yaml"
CDS_DATASET = "reanalysis-era5-single-levels"
# Margin (km) added around the fine-grid domain so the download fully covers
# the 48 x 48 km study area plus context for its edges.
DOMAIN_MARGIN_KM = 12.0

SETUP_INSTRUCTIONS = """
No CDS API key found. To use real ERA5 data you need a (free) one-time setup:

  1. Register at https://cds.climate.copernicus.eu
  2. Accept the ERA5 dataset licence on your CDS profile page
  3. Create ~/.cdsapirc containing:
       url: https://cds.climate.copernicus.eu/api
       key: <YOUR-PERSONAL-KEY>
     (or export CDSAPI_URL and CDSAPI_KEY environment variables)
  4. Install the client library:  pip install cdsapi

Then re-run this script. See https://cds.climate.copernicus.eu/how-to-api
for details. Meanwhile the synthetic generator
(python -m uhi_downscaling.data.synthetic) works without any key.
"""


def cds_key_present() -> bool:
    """Return True when CDS credentials are configured (file or env vars)."""
    url = os.environ.get("CDSAPI_URL")
    key = os.environ.get("CDSAPI_KEY")
    if url and key:
        return True
    rc = Path.home() / ".cdsapirc"
    return rc.is_file() and rc.read_text(encoding="utf-8").strip() != ""


def resolve_date_range(cfg: dict[str, Any], start: str | None, end: str | None) -> list[date]:
    """Parse/derive the inclusive list of dates to download."""
    if start is None:
        start = str(cfg["time"]["start_date"])
    if end is None:
        end = (
            date.fromisoformat(start)
            + timedelta(days=int(cfg["time"]["n_days"]) - 1)
        ).isoformat()
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    if last < first:
        raise ValueError(f"--end ({end}) is before --start ({start})")
    if (last - first).days + 1 > 366 * 2:
        raise ValueError("date range longer than two years is not supported")
    return [first + timedelta(days=k) for k in range((last - first).days + 1)]


def build_request(cfg: dict[str, Any], dates: list[date], grid_deg: float) -> dict[str, Any]:
    """Build the CDS API request dict for the domain defined in ``cfg``.

    The area follows the CDS convention ``[north, west, south, east]`` and is
    derived from the grid centre (``grid.center_lat/center_lon``) plus the
    fine-domain half extent and a margin, converted from km to degrees the
    same way as :func:`uhi_downscaling.data.synthetic.build_coordinates`.
    """
    from uhi_downscaling.data.synthetic import KMS_PER_DEG_LAT, KMS_PER_DEG_LON_EQUATOR

    half_km = float(cfg["grid"]["n_fine"]) * float(cfg["grid"]["fine_spacing_km"]) / 2.0
    margin_km = half_km + DOMAIN_MARGIN_KM
    center_lat = float(cfg["grid"]["center_lat"])
    center_lon = float(cfg["grid"]["center_lon"])
    kms_per_deg_lon = KMS_PER_DEG_LON_EQUATOR * math.cos(math.radians(center_lat))

    north = center_lat + margin_km / KMS_PER_DEG_LAT
    south = center_lat - margin_km / KMS_PER_DEG_LAT
    west = center_lon - margin_km / kms_per_deg_lon
    east = center_lon + margin_km / kms_per_deg_lon

    by_month: "OrderedDict[tuple[int, int], set[int]]" = OrderedDict()
    for day in dates:
        by_month.setdefault((day.year, day.month), set()).add(day.day)

    request: dict[str, Any] = {
        "variable": ["2m_temperature"],
        "year": sorted({y for y, _ in by_month}),
        "month": sorted({f"{m:02d}" for _, m in by_month}),
        "day": sorted({f"{d:02d}" for days in by_month.values() for d in days}),
        "time": [f"{h:02d}:00" for h in range(24)],
        "area": [round(north, 4), round(west, 4), round(south, 4), round(east, 4)],
        "grid": [grid_deg, grid_deg],
        "data_format": "netcdf",
        "download_format": "unarchived",
    }
    return request


def default_output(cfg: dict[str, Any], dates: list[date]) -> Path:
    """Default netCDF output path: ``<data_dir>/era5/era5_t2m_<start>_<end>.nc``."""
    out = (
        Path(cfg["paths"]["data_dir"])
        / "era5"
        / f"era5_t2m_{dates[0].isoformat()}_{dates[-1].isoformat()}.nc"
    )
    return out


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: download ERA5 t2m or fail gracefully with guidance."""
    parser = argparse.ArgumentParser(
        description=(
            "Download hourly ERA5 2 m temperature over the pipeline's Cairo "
            "domain from the Copernicus CDS (requires a free CDS API key)."
        )
    )
    parser.add_argument("--config", default=DEFAULT_CONFIG, help="Experiment YAML config (defines the domain).")
    parser.add_argument("--start", default=None, help="First date, ISO format (default: config start_date).")
    parser.add_argument("--end", default=None, help="Last date, inclusive (default: config start_date + n_days - 1).")
    parser.add_argument("--grid", type=float, default=0.25, help="Download grid resolution in degrees (default 0.25).")
    parser.add_argument("--out", default=None, help="Output netCDF path (default: <data_dir>/era5/...).")
    args = parser.parse_args(argv)

    from uhi_downscaling.config import load_config

    cfg = load_config(args.config)
    dates = resolve_date_range(cfg, args.start, args.end)
    out = Path(args.out) if args.out else default_output(cfg, dates)
    request = build_request(cfg, dates, args.grid)

    print(f"domain area (N, W, S, E): {request['area']}")
    print(f"date range: {dates[0]} .. {dates[-1]}  ({len(dates)} days, hourly)")
    print(f"grid: {args.grid} deg   output: {out}")

    if not cds_key_present():
        print(SETUP_INSTRUCTIONS)
        return 1
    try:
        import cdsapi  # noqa: PLC0415  (optional dependency, imported lazily)
    except ImportError:
        print("The 'cdsapi' package is not installed. Run:  pip install cdsapi")
        print("Then re-run this script.")
        return 1

    out.parent.mkdir(parents=True, exist_ok=True)
    print("submitting CDS request (queue times of minutes to hours are normal) ...")
    try:
        client = cdsapi.Client(quiet=False)
        client.retrieve(CDS_DATASET, request).download(str(out))
    except Exception as exc:  # noqa: BLE001  (report any CDS failure clearly)
        print(f"\nCDS download failed: {exc}")
        print("Common causes: licence not accepted on the CDS website, invalid")
        print("~/.cdsapirc key, or the request sitting in the server queue.")
        return 1
    print(f"downloaded: {out}")
    print("Note: converting this netCDF into the pipeline zarr format is future")
    print("work; the synthetic generator remains the default data source.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
