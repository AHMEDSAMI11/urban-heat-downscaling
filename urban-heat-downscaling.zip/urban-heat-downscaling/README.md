# urban-heat-downscaling

[![Python](https://img.shields.io/badge/python-3.12-blue)](https://www.python.org/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.x-ee4c2c)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)

Machine-learning downscaling of urban 2 m air-temperature fields: recovering a
48 x 48 grid at 1 km spacing from an ERA5-style coarse 6 x 6 grid at 8 km, using
a small residual CNN with a gradient-boosting baseline, plus a rigorous
evaluation harness (temporal split, spatial holdout, per-hour and per-region
breakdowns on real geohash cells).

## Why downscaling

- Reanalysis products such as ERA5 are gridded at ~25-31 km, which is far too
  coarse to resolve the neighbourhood-scale urban heat island that matters for
  heat warnings, cooling-centre planning, and intervention design.
- Statistical downscaling learns the mapping from coarse forcing + static
  surface descriptors (land cover, terrain, buildings) to the fine-scale field,
  and runs in milliseconds instead of the cost of a convection-permitting model.
- The same train/evaluate harness generalises to any gridded downscaling task
  (temperature, humidity, pollutant fields) with strict spatial and temporal
  generalisation tests.

## Data flow

```
coarse T2M (6x6 @ 8 km) --- bilinear upsample ---> 48x48 base field ---+
                                                                      |--- [residual CNN] ---> fine T2M (48x48 @ 1 km)
static predictors (land cover fractions, elevation, building height) --+
```

The CNN predicts the *residual* over the bilinear baseline: the baseline
already carries the synoptic signal, so the network only has to learn the
local, land-cover-driven departures. This makes training stable and keeps the
model small (274,737 parameters).

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cpu   # CPU-only wheel
pip install -e ".[dev]"

uhi-generate-data --config configs/exp_default.yaml   # ~1 min, writes data/synthetic.zarr
uhi-train         --config configs/exp_default.yaml   # ~3 min on a laptop CPU
uhi-evaluate      --config configs/exp_default.yaml   # ~1.5 min, writes results/
pytest -q                                            # 29 tests
```

All three entry points accept `--config` (default `configs/exp_default.yaml`).
Every experiment is deterministic given the seed (`42`).

## Data

### Synthetic benchmark (default)

`src/uhi_downscaling/data/synthetic.py` generates a physically-motivated
hourly dataset for 45 consecutive days starting 2023-07-01 over a 48 x 48 km
domain centred on Cairo (30.05 N, 31.23 E) - 1,080 hourly samples:

- diurnal cycle peaking around 14:00 local solar time;
- urban heat island strongest after sunset, driven by land-cover fractions
  (urban core, industrial, parks, water, roads);
- terrain lapse rate of -6.5 C/km on a synthetic elevation field;
- smooth advective noise (Gaussian-filtered) so the field is not trivially
  separable;
- the coarse grid is the **exact 8 x 8 block mean** of the fine field, so the
  downscaling task is well-posed and baselines are meaningful.

Storage is `xarray` + `zarr` (`data/synthetic.zarr`), with real lat/lon
coordinates so that region grouping uses a genuine geohash implementation
(`src/uhi_downscaling/data/geohash.py`, dependency-free).

### Real ERA5 data

`scripts/download_era5.py` fetches real ERA5-Land 2 m temperature via the
Copernicus CDS API and coarsens/aligns it to the same schema. Register a free
CDS account, put your key in `~/.cdsapirc`, then run the script; the pipeline
itself is unchanged.

## Models

| Model | File | Notes |
|---|---|---|
| Residual CNN | `src/uhi_downscaling/models/cnn.py` | 3-stage encoder (48-64-96 channels), predicts residual over bilinear baseline |
| GBM baseline | `src/uhi_downscaling/models/gbm.py` | `HistGradientBoostingRegressor` on per-pixel features (upsampled coarse T2M + all static predictors) |
| Bilinear baseline | - | Upsampled coarse grid; the reference every learned model must beat |

## Evaluation design

- **Temporal split** - train on days 1-36 (864 samples), validate on days 37-39
  (72), test on days 40-45 (144). Normalisation statistics come from the
  training split only.
- **Spatial holdout** - a second CNN/GBM is trained only on west-half pixels
  and scored on east-half pixels, quantifying generalisation outside training
  support rather than interpolation.
- **Per-hour breakdown** - RMSE for each of the 24 hours of day.
- **Per-region breakdown** - RMSE per geohash-4 cell (~20-30 km regions) of the
  real Cairo-area domain.

## Results (actual CPU run)

Full metrics live in `results/summary.json` and a human-readable version in
`results/report.md`.

Overall, test split (144 unseen hourly timesteps):

| Method | RMSE (C) | MAE (C) | RMSE improvement vs bilinear |
|---|---|---|---|
| Bilinear upsample | 0.474 | 0.352 | - |
| GBM (HistGradientBoosting) | **0.294** | **0.216** | 37.9% |
| Residual CNN (275k params) | 0.316 | 0.230 | 33.3% |

Spatial holdout (trained on west half, scored on east half):

| Method | RMSE (C) | MAE (C) | RMSE improvement vs bilinear |
|---|---|---|---|
| Bilinear upsample | 0.521 | 0.385 | - |
| GBM | **0.386** | **0.289** | 26.0% |
| Residual CNN | 0.400 | 0.300 | 23.2% |

An honest observation: the GBM baseline edges out the CNN on this synthetic
benchmark (both clearly beat bilinear). Plausible reasons: the generator's
land-cover effects are largely *pointwise* functions of static predictors,
which is exactly what a per-pixel GBM captures, and 864 training samples is
small for a CNN. Making the CNN win via convective/adveective generators and
larger datasets is tracked in the roadmap - the harness is built to test that.

## Figures

Test snapshot - coarse baseline vs CNN vs truth:

![Test snapshot map comparison](results/figures/test_map_comparison.png)

Prediction vs truth, CNN on the test split:

![Prediction vs truth scatter](results/figures/test_scatter.png)

RMSE by hour of day:

![RMSE by hour](results/figures/rmse_by_hour.png)

RMSE by geohash region:

![RMSE by region](results/figures/rmse_by_region.png)

Spatial holdout snapshot:

![Holdout map comparison](results/figures/holdout_map_comparison.png)

## Project structure

```
urban-heat-downscaling/
+-- configs/exp_default.yaml        # single source of truth for an experiment
+-- scripts/download_era5.py        # real-data path (CDS API)
+-- src/uhi_downscaling/
|   +-- data/synthetic.py           # physics-based generator -> xarray/zarr
|   +-- data/geohash.py             # dependency-free geohash codec
|   +-- data/dataset.py             # torch Dataset + normalisation
|   +-- models/cnn.py               # residual CNN
|   +-- models/gbm.py               # gradient-boosting baseline
|   +-- metrics.py                  # RMSE / MAE / bias
|   +-- train.py                    # training loop, checkpoints, run metrics
|   +-- evaluate.py                 # splits, breakdowns, report + summary
|   +-- viz.py                      # matplotlib figures
+-- tests/                          # 29 fast unit tests
+-- results/                        # committed outputs of the reference run
```

## Roadmap

- [ ] Plug real ERA5-Land + static Copernicus land cover into the pipeline
- [ ] Advection-driven synthetic generator (makes the CNN's inductive bias matter)
- [ ] Multi-GPU DDP training (currently single-device CPU/GPU)
- [ ] Probabilistic downscaling (quantile heads) and uncertainty maps
- [ ] Zarr streaming for datasets that do not fit in memory

## License

[MIT](LICENSE) - Copyright (c) 2026 Ahmed Soliman
