# Evaluation report - cnn_default

Generated 2026-11-20T17:08:27+00:00 (UTC) on device `cpu` with config `exp_default.yaml`.

## Test split

144 hourly timesteps (days 40-45, 1-based day range of a 45-day dataset). The models never saw these timesteps; normalisation statistics come from the training split only.

## Overall metrics (test split)

| Method | RMSE (C) | MAE (C) | Mean bias (C) |
|---|---|---|---|
| bilinear | 0.474 | 0.352 | -0.000 (+0.0% RMSE vs bilinear) |
| gbm | 0.294 | 0.216 | 0.004 (+37.9% RMSE vs bilinear) |
| cnn | 0.316 | 0.230 | -0.006 (+33.3% RMSE vs bilinear) |

## RMSE by hour of day

| Hour | n | Bilinear | GBM | CNN |
|---|---|---|---|---|
| 00:00 | 6 | 0.431 | 0.287 | 0.315 |
| 01:00 | 6 | 0.438 | 0.293 | 0.330 |
| 02:00 | 6 | 0.458 | 0.289 | 0.326 |
| 03:00 | 6 | 0.464 | 0.289 | 0.333 |
| 04:00 | 6 | 0.476 | 0.294 | 0.337 |
| 05:00 | 6 | 0.472 | 0.285 | 0.312 |
| 06:00 | 6 | 0.494 | 0.313 | 0.338 |
| 07:00 | 6 | 0.482 | 0.310 | 0.326 |
| 08:00 | 6 | 0.484 | 0.293 | 0.304 |
| 09:00 | 6 | 0.504 | 0.302 | 0.317 |
| 10:00 | 6 | 0.487 | 0.293 | 0.301 |
| 11:00 | 6 | 0.496 | 0.302 | 0.312 |
| 12:00 | 6 | 0.511 | 0.293 | 0.314 |
| 13:00 | 6 | 0.507 | 0.295 | 0.319 |
| 14:00 | 6 | 0.519 | 0.296 | 0.326 |
| 15:00 | 6 | 0.507 | 0.303 | 0.322 |
| 16:00 | 6 | 0.497 | 0.294 | 0.321 |
| 17:00 | 6 | 0.480 | 0.282 | 0.301 |
| 18:00 | 6 | 0.474 | 0.303 | 0.317 |
| 19:00 | 6 | 0.457 | 0.296 | 0.309 |
| 20:00 | 6 | 0.440 | 0.283 | 0.292 |
| 21:00 | 6 | 0.425 | 0.287 | 0.299 |
| 22:00 | 6 | 0.432 | 0.292 | 0.307 |
| 23:00 | 6 | 0.424 | 0.289 | 0.307 |

## RMSE by region (geohash precision 4, ~20-30 km cells)

| Region | Centre (lat, lon) | Pixels | Bilinear | GBM | CNN |
|---|---|---|---|---|---|
| `stq1` | 29.795, 31.113 | 180 | 0.507 | 0.386 | 0.395 |
| `stq3` | 29.795, 31.465 | 108 | 0.484 | 0.391 | 0.425 |
| `stq4` | 29.971, 31.113 | 570 | 0.501 | 0.253 | 0.270 |
| `stq5` | 30.146, 31.113 | 570 | 0.459 | 0.249 | 0.270 |
| `stq6` | 29.971, 31.465 | 342 | 0.499 | 0.272 | 0.291 |
| `stq7` | 30.146, 31.465 | 342 | 0.344 | 0.266 | 0.274 |
| `stqh` | 30.322, 31.113 | 120 | 0.519 | 0.388 | 0.438 |
| `stqk` | 30.322, 31.465 | 72 | 0.587 | 0.483 | 0.554 |

## Spatial holdout: train west half, evaluate east half

CNN and GBM trained only on west-half pixels (columns 0-23); metrics computed on east-half pixels (columns 24-47) of the test split. Bilinear baseline scored on the same pixels.

| Method | RMSE (C) | MAE (C) | Mean bias (C) |
|---|---|---|---|
| bilinear | 0.521 | 0.385 | 0.035 (+0.0% RMSE vs bilinear) |
| gbm | 0.386 | 0.289 | 0.023 (+26.0% RMSE vs bilinear) |
| cnn | 0.400 | 0.300 | -0.006 (+23.2% RMSE vs bilinear) |

Both learned models are evaluated strictly outside their training support, so these errors quantify spatial generalisation rather than interpolation.

## Figures

![Test snapshot map comparison](figures/test_map_comparison.png)

![Prediction vs truth scatter](figures/test_scatter.png)

![RMSE by hour of day](figures/rmse_by_hour.png)

![RMSE by region](figures/rmse_by_region.png)

![Spatial holdout map comparison](figures/holdout_map_comparison.png)
