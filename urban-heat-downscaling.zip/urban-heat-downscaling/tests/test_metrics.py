"""Hand-computed metric checks for uhi_downscaling.metrics."""

from __future__ import annotations

import numpy as np
import pytest

from uhi_downscaling.metrics import mae, mean_bias, rmse

PRED = np.array([1.0, 2.0, 3.0])
TRUTH = np.array([2.0, 2.0, 2.0])  # errors: -1, 0, +1


def test_rmse_hand_computed():
    # sqrt((1 + 0 + 1) / 3)
    assert rmse(PRED, TRUTH) == pytest.approx(np.sqrt(2.0 / 3.0), rel=1e-12)


def test_mae_hand_computed():
    assert mae(PRED, TRUTH) == pytest.approx(2.0 / 3.0, rel=1e-12)


def test_mean_bias_hand_computed():
    # (-1 + 0 + 1) / 3 = 0, so use an asymmetric example as well
    assert mean_bias(PRED, TRUTH) == pytest.approx(0.0, abs=1e-12)
    assert mean_bias([3.0, 3.0], [2.0, 1.0]) == pytest.approx(1.5, rel=1e-12)


def test_rmse_zero_for_perfect_prediction():
    assert rmse(TRUTH, TRUTH) == 0.0


def test_metrics_on_2d_fields():
    pred = np.ones((2, 2))
    truth = np.zeros((2, 2))
    assert rmse(pred, truth) == pytest.approx(1.0)
    assert mae(pred, truth) == pytest.approx(1.0)
    assert mean_bias(pred, truth) == pytest.approx(1.0)


def test_shape_mismatch_raises():
    with pytest.raises(ValueError):
        rmse([1.0], [1.0, 2.0])
    with pytest.raises(ValueError):
        mae(np.zeros((2, 2)), np.zeros((2, 3)))


def test_empty_arrays_raise():
    with pytest.raises(ValueError):
        rmse([], [])
    with pytest.raises(ValueError):
        mean_bias(np.array([]), np.array([]))
