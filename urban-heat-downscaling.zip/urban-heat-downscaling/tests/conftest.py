"""Shared pytest fixtures: a small deterministic synthetic dataset."""

from __future__ import annotations

from typing import Any

import pytest

from uhi_downscaling.data.synthetic import generate_dataset


@pytest.fixture(scope="session")
def small_cfg() -> dict[str, Any]:
    """Minimal config: 32 km grid, 2 days - fast to generate."""
    return {
        "experiment": {"seed": 7},
        "grid": {
            "n_fine": 32,
            "fine_spacing_km": 1.0,
            "coarsening_factor": 8,
            "center_lat": 30.05,
            "center_lon": 31.23,
        },
        "time": {"start_date": "2023-07-01", "n_days": 2},
    }


@pytest.fixture(scope="session")
def small_dataset(small_cfg: dict[str, Any]):
    """Session-scoped in-memory xarray dataset (no zarr write)."""
    return generate_dataset(small_cfg)
