"""Property tests for the synthetic physics generator."""

from __future__ import annotations

import numpy as np

from uhi_downscaling.data.synthetic import block_mean_aggregate


def test_shapes(small_dataset):
    ds = small_dataset
    assert ds["t2m_fine"].shape == (48, 32, 32)   # 2 days x 24 h, 32 km grid
    assert ds["t2m_coarse"].shape == (48, 4, 4)   # factor 8 -> 4 km blocks... (32/8)
    assert ds["t2m_fine"].dims == ("time", "lat", "lon")
    assert ds["t2m_coarse"].dims == ("time", "lat_c", "lon_c")


def test_diurnal_cycle_peaks_at_14(small_dataset):
    """Domain-mean temperature must peak at 14:00 local solar time."""
    hourly = (
        small_dataset["t2m_fine"].values.mean(axis=(1, 2)).reshape(-1, 24).mean(axis=0)
    )
    assert int(np.argmax(hourly)) == 14


def test_parks_cooler_than_urban_core_in_afternoon(small_dataset):
    ds = small_dataset
    park = ds["park_frac"].values
    urban = ds["urban_frac"].values
    fine = ds["t2m_fine"].values
    hours = ds["hour"].values

    park_pixels = park > 0.5
    urban_pixels = urban > 0.5
    assert park_pixels.any(), "fixture should contain strong park cells"
    assert urban_pixels.any(), "fixture should contain dense urban cells"

    afternoon = (hours >= 12) & (hours <= 18)  # park cooling is strongest then
    park_temp = fine[afternoon][:, park_pixels].mean()
    urban_temp = fine[afternoon][:, urban_pixels].mean()
    assert park_temp < urban_temp - 0.3


def test_coarse_is_exact_block_mean_of_fine(small_dataset):
    fine = small_dataset["t2m_fine"].values
    coarse = small_dataset["t2m_coarse"].values
    recomputed = block_mean_aggregate(fine, 8)
    np.testing.assert_allclose(coarse, recomputed, rtol=0.0, atol=1e-6)


def test_block_mean_manual_2x2_example():
    """Hand-checked 2 x 2 aggregation of a 4 x 4 field with factor 2."""
    field = np.arange(16, dtype=np.float64).reshape(4, 4)
    out = block_mean_aggregate(field, 2)
    expected = np.array([[2.5, 4.5], [10.5, 12.5]])
    np.testing.assert_allclose(out, expected, rtol=0.0, atol=1e-12)


def test_block_mean_rejects_indivisible_shape():
    with __import__("pytest").raises(ValueError):
        block_mean_aggregate(np.zeros((5, 5)), 2)
