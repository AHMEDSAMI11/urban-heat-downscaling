"""Tests for the pure-python geohash encoder/decoder."""

from __future__ import annotations

import pytest

from uhi_downscaling.data.geohash import decode, decode_bounds, encode, group_by_prefix


def test_known_value_wikipedia_example():
    """Classic published example: (57.64911, 10.40744) -> u4pruydqqvj."""
    assert encode(57.64911, 10.40744, precision=11) == "u4pruydqqvj"


def test_known_value_decodes_back():
    lat, lon = decode("u4pruydqqvj")
    assert lat == pytest.approx(57.64911, abs=1e-4)
    assert lon == pytest.approx(10.40744, abs=1e-4)


@pytest.mark.parametrize(
    "lat,lon,precision",
    [(30.05, 31.23, 6), (0.0, 0.0, 4), (-33.9, 18.4, 5), (89.9, 179.9, 8), (-45.0, -100.0, 3)],
)
def test_roundtrip_stays_inside_cell(lat, lon, precision):
    geohash = encode(lat, lon, precision)
    lat_lo, lat_hi, lon_lo, lon_hi = decode_bounds(geohash)
    assert lat_lo <= lat <= lat_hi
    assert lon_lo <= lon <= lon_hi
    center_lat, center_lon = decode(geohash)
    assert lat_lo <= center_lat <= lat_hi
    assert lon_lo <= center_lon <= lon_hi


def test_longer_precision_shrinks_cell():
    small = decode_bounds(encode(30.05, 31.23, 6))
    big = decode_bounds(encode(30.05, 31.23, 3))
    assert (small[1] - small[0]) < (big[1] - big[0])
    assert (small[3] - small[2]) < (big[3] - big[2])


def test_group_by_prefix_deterministic_and_geographic():
    points = [(30.05, 31.20), (30.06, 31.21), (48.85, 2.35)]  # two Cairo, one Paris
    groups = group_by_prefix(points, precision=3)
    # The two nearby Cairo points share one precision-3 cell (~156 km).
    key = encode(30.05, 31.20, 3)
    assert groups[key] == [(30.05, 31.2), (30.06, 31.21)]
    # Paris lands in a different cell.
    assert encode(48.85, 2.35, 3) != key
    assert len(groups[encode(48.85, 2.35, 3)]) == 1


def test_invalid_character_raises():
    with pytest.raises(ValueError):
        decode_bounds("u4pruydqqa")  # 'a' is not in the geohash base-32 alphabet
    with pytest.raises(ValueError):
        decode_bounds("u4pruydqqi")  # 'i' is excluded as well


def test_out_of_range_coordinates_raise():
    with pytest.raises(ValueError):
        encode(95.0, 0.0, 4)
    with pytest.raises(ValueError):
        encode(0.0, -200.0, 4)
    with pytest.raises(ValueError):
        encode(0.0, 0.0, 0)
