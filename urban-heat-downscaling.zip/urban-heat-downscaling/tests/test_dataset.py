"""Tests for the torch dataset and its z-score normalisation contract."""

from __future__ import annotations

import numpy as np

from uhi_downscaling.data.dataset import (
    DownscalingDataset,
    bilinear_upsample,
    compute_norm_stats,
)


def test_bilinear_upsample_constant_field_is_constant():
    coarse = np.full((3, 2, 2), 5.0, dtype=np.float32)
    up = bilinear_upsample(coarse, factor=4)
    assert up.shape == (3, 8, 8)
    np.testing.assert_allclose(up, 5.0, rtol=0.0, atol=1e-6)


def test_bilinear_upsample_explicit_out_shape():
    up = bilinear_upsample(np.zeros((1, 3, 3), dtype=np.float32), factor=8, out_hw=(6, 6))
    assert up.shape == (1, 6, 6)


def test_normalization_roundtrip(small_dataset):
    """De-normalising the stored normalised target must reproduce the residual."""
    stats = compute_norm_stats(small_dataset, (0, 24), factor=8)
    dset = DownscalingDataset(small_dataset, (0, 24), stats, factor=8, name="unit")

    assert dset.inputs.shape == (24, 10, 32, 32)   # bilinear + 7 static + hour sin/cos
    assert dset.targets_norm.shape == (24, 32, 32)
    assert dset.residual.shape == (24, 32, 32)

    recovered = dset.denormalize_residual(dset.targets_norm)
    np.testing.assert_allclose(recovered, dset.residual, rtol=1e-5, atol=1e-5)


def test_residual_definition_and_hours(small_dataset):
    stats = compute_norm_stats(small_dataset, (0, 24), factor=8)
    dset = DownscalingDataset(small_dataset, (0, 24), stats, factor=8, name="unit")

    np.testing.assert_allclose(
        dset.residual,
        small_dataset["t2m_fine"].values[:24] - dset.upscaled,
        atol=1e-6,
    )

    # Normalised target has (approximately) zero mean and unit std.
    assert abs(float(dset.targets_norm.mean())) < 1e-4
    assert abs(float(dset.targets_norm.std()) - 1.0) < 1e-4

    # Hour coordinate follows the 24 h cycle of the first day.
    assert int(dset.hours[0]) == 0 and int(dset.hours[13]) == 13 and int(dset.hours[23]) == 23


def test_compute_norm_stats_keys_match_channels(small_dataset):
    stats = compute_norm_stats(small_dataset, (0, 12), factor=8)
    names = [entry["name"] for entry in stats["input_channels"]]
    assert names[0] == "bilinear_t2m"
    assert names[1:] == [
        "urban_frac",
        "industrial_frac",
        "park_frac",
        "water_frac",
        "road_frac",
        "elevation",
        "building_height",
        "hour_sin",
        "hour_cos",
    ]
    assert stats["target"]["name"] == "fine_residual_t2m"
    assert all(entry["std"] > 0 for entry in stats["input_channels"])
